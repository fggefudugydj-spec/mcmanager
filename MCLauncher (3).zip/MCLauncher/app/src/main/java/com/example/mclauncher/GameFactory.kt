package com.example.mclauncher

import android.app.Activity
import android.app.AppComponentFactory
import android.content.Intent
import android.os.Bundle
import java.io.File

/** نشاط يقفل نفسه فورًا، نستخدمه لإيقاف حلقة الانهيار. */
class StopActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        finish()
    }
}

/** يُنشئ نشاط ماين كرافت من ملف APK المختار. */
class GameFactory : AppComponentFactory() {
    override fun instantiateActivity(cl: ClassLoader, className: String, intent: Intent?): Activity {
        if (className == MC_MAIN && GameLoader.dir != null) {
            if (GameLoader.stop) {
                GameLog.w("Factory: إيقاف الحلقة")
                return StopActivity()
            }
            val libDir = File(GameLoader.dir!!, "lib")
            GameLog.w("Factory: المكتبات=${libDir.list()?.size} libminecraftpe=${File(libDir, "libminecraftpe.so").exists()}")
            if (GameLoader.injected) {
                GameLog.w("Factory: الكلاس داخل classloader التطبيق، إنشاء عادي")
                return super.instantiateActivity(cl, className, intent)
            }
            GameLog.w("Factory: تحميل $className عبر DexClassLoader منفصل")
            val c = GameLoader.get(cl).loadClass(className)
            GameLog.w("Factory: تحمّل الكلاس، الأب=${c.superclass?.name}")
            val ctor = c.getDeclaredConstructor()
            ctor.isAccessible = true
            val a = ctor.newInstance() as Activity
            GameLog.w("Factory: تم إنشاء النشاط")
            return a
        }
        return super.instantiateActivity(cl, className, intent)
    }
}
