# MCLaunch
Single-version launcher test.
