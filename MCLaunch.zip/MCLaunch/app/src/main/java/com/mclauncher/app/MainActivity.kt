package com.mclauncher.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {
    private val REQ_IMPORT = 1
    private val versionDir by lazy { File(filesDir, "current").apply { mkdirs() } }
    private val logStore by lazy { LogStore(File(filesDir, "launcher.log")) }
    private lateinit var out: TextView
    private lateinit var scroll: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }
        out = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(out) }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 56, 24, 24)
            addView(btn("1) Import Minecraft APK") { pickApk() })
            addView(btn("2) Run launch test") { runTest() })
            addView(btn("Share log") { shareLog() })
            addView(btn("Clear log") { logStore.clear(); showLog() })
            addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        })
        showLog()   // shows what happened last time, even if the app crashed
    }

    private fun showLog() = runOnUiThread {
        out.text = logStore.read().ifEmpty { "Log is empty." }
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun log(line: String) { logStore.add(line); showLog() }

    private fun pickApk() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }, REQ_IMPORT)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != REQ_IMPORT || resultCode != RESULT_OK || uri == null) return
        log("--- import ---")
        Thread {
            val tmp = File(versionDir, "game.tmp")
            try {
                contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { i.copyTo(it) } }
                val pi = packageManager.getPackageArchiveInfo(tmp.path, 0)
                    ?: error("not a valid APK")
                if (pi.packageName != NativeStore.MC_PACKAGE)
                    error("not the official Minecraft APK (package ${pi.packageName})")
                val dest = File(versionDir, "game.apk")
                File(versionDir, "libs").deleteRecursively()
                dest.setWritable(true); dest.delete()
                tmp.renameTo(dest)
                dest.setReadOnly()   // Android 14+ refuses to load code from a writable file
                val info = NativeStore.inspect(dest)
                log("Imported Minecraft ${pi.versionName}, ${dest.length() / 1048576} MB")
                log("ABIs inside: ${info.abis}, libminecraftpe.so present: ${info.hasMain}")
                if (!info.hasMain) log("WARN: this APK has no native libs (split install?). Launch test will fail.")
            } catch (e: Exception) {
                tmp.delete()
                log("Import failed: ${e.message}")
            }
        }.start()
    }

    private fun runTest() {
        log("=== launch test ===")
        Thread { Launcher.run(this, versionDir) { log(it) } }.start()
    }

    private fun shareLog() {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, logStore.read())
        }, "Share log"))
    }
}
