package com.mclauncher.app

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Appends every line straight to disk, so the log survives a native crash. */
class LogStore(private val file: File) {
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    @Synchronized fun add(line: String) {
        file.appendText("[${fmt.format(Date())}] $line\n")
    }
    fun read(): String = if (file.isFile) file.readText() else ""
    fun clear() { file.delete() }
}
