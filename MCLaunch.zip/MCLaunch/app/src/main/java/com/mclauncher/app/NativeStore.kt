package com.mclauncher.app

import android.os.Build
import java.io.File
import java.util.zip.ZipFile

object NativeStore {
    const val MC_PACKAGE = "com.mojang.minecraftpe"
    const val MAIN_LIB = "libminecraftpe.so"

    data class ApkInfo(val abis: List<String>, val libCount: Int, val hasMain: Boolean)

    fun inspect(apk: File): ApkInfo {
        val abis = sortedSetOf<String>()
        var count = 0
        var main = false
        ZipFile(apk).use { z ->
            for (e in z.entries()) {
                val parts = e.name.split('/')
                if (parts.size == 3 && parts[0] == "lib" && parts[2].endsWith(".so")) {
                    abis += parts[1]; count++
                    if (parts[2] == MAIN_LIB) main = true
                }
            }
        }
        return ApkInfo(abis.toList(), count, main)
    }

    /** First device ABI (in the device's own preference order) that the APK ships. */
    fun pickAbi(apk: File): String? {
        val inApk = inspect(apk).abis
        return Build.SUPPORTED_ABIS.firstOrNull { it in inApk }
    }

    /** Extracts every .so of the ABI; writes via temp file and checks size. */
    fun extractAll(apk: File, abi: String, outDir: File): List<File> {
        outDir.mkdirs()
        val result = mutableListOf<File>()
        ZipFile(apk).use { z ->
            for (e in z.entries()) {
                val n = e.name
                if (!n.startsWith("lib/$abi/") || !n.endsWith(".so")) continue
                val dest = File(outDir, n.substringAfterLast('/'))
                if (dest.isFile && dest.length() == e.size) { result += dest; continue }
                val tmp = File(outDir, dest.name + ".tmp")
                z.getInputStream(e).use { i -> tmp.outputStream().use { i.copyTo(it) } }
                if (e.size >= 0 && tmp.length() != e.size) {
                    tmp.delete(); error("Size mismatch: ${dest.name}")
                }
                dest.delete()
                if (!tmp.renameTo(dest)) { tmp.copyTo(dest, true); tmp.delete() }
                dest.setReadable(true, false)
                result += dest
            }
        }
        return result
    }
}
