package com.mclauncher.app

import android.content.Context
import android.os.Build
import dalvik.system.DexClassLoader
import java.io.File

/** Experimental: loads the game's native libraries step by step and logs every step. */
object Launcher {
    fun run(ctx: Context, versionDir: File, log: (String) -> Unit) {
        val apk = File(versionDir, "game.apk")
        if (!apk.isFile) { log("FAIL: no APK imported yet"); return }
        log("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), device ABIs: ${Build.SUPPORTED_ABIS.joinToString()}")
        log("APK: ${apk.length() / 1048576} MB")

        val info = NativeStore.inspect(apk)
        log("ABIs inside APK: ${info.abis}, native libs: ${info.libCount}, has $MC_MAIN: ${info.hasMain}")
        val abi = NativeStore.pickAbi(apk)
        if (abi == null) {
            log("FAIL: this APK has no native libs for your device. If it is a split install, the config.<abi> part is missing.")
            return
        }
        log("Using ABI: $abi")

        val libDir = File(versionDir, "libs/$abi")
        val libs = try { NativeStore.extractAll(apk, abi, libDir) } catch (e: Exception) {
            log("FAIL: extraction error: $e"); return
        }
        log("Extracted ${libs.size} libs to ${libDir.path}")
        val main = libs.firstOrNull { it.name == NativeStore.MAIN_LIB }
        if (main == null) { log("FAIL: ${NativeStore.MAIN_LIB} is not inside this APK"); return }

        // Load dependencies first; retry until no more progress (handles load order).
        val pending = libs.filter { it !== main }.toMutableList()
        var progress = true
        while (pending.isNotEmpty() && progress) {
            progress = false
            val iter = pending.iterator()
            while (iter.hasNext()) {
                val f = iter.next()
                try {
                    System.load(f.absolutePath)
                    log("loaded ${f.name}")
                    iter.remove(); progress = true
                } catch (e: UnsatisfiedLinkError) {
                    log("not yet ${f.name}: ${e.message?.take(100)}")
                }
            }
        }
        if (pending.isNotEmpty()) log("WARN: could not load ${pending.map { it.name }}")

        log("Loading ${NativeStore.MAIN_LIB} (if the app closes here, it was a native crash)")
        try {
            System.load(main.absolutePath)
            log("OK: ${NativeStore.MAIN_LIB} loaded")
        } catch (e: UnsatisfiedLinkError) {
            log("FAIL: ${e.message}"); return
        }

        try {
            val cl = DexClassLoader(apk.absolutePath, null, libDir.absolutePath, ctx.classLoader)
            val c = cl.loadClass("com.mojang.minecraftpe.MainActivity")
            log("OK: game class found: ${c.name}")
        } catch (e: Throwable) {
            log("FAIL: game class: $e")
        }
        log("DONE. Native library is loaded. Starting the game screen is the next stage.")
    }

    private const val MC_MAIN = NativeStore.MAIN_LIB
}
