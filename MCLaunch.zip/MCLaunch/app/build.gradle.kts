plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.mclauncher.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.mclauncher.app"
        minSdk = 28
        targetSdk = 34
        versionCode = 1
        versionName = "0.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
