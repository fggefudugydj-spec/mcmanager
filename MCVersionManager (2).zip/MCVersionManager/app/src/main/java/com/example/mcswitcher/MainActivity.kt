package com.example.mcswitcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.Settings
import android.widget.Toast
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

// ---------------- أدوات النظام ----------------

fun installedVersion(ctx: Context): Pair<String, Long>? = try {
    val i = ctx.packageManager.getPackageInfo(MC_PKG, 0)
    (i.versionName ?: "?") to PackageInfoCompat.getLongVersionCode(i)
} catch (e: Exception) { null }

fun installApk(ctx: Context, f: File) {
    if (!ctx.packageManager.canRequestPackageInstalls()) {
        Toast.makeText(ctx, "اسمح للتطبيق بتثبيت التطبيقات ثم ارجع", Toast.LENGTH_LONG).show()
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")))
        return
    }
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
    ctx.startActivity(
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    )
}

fun uninstallMc(ctx: Context) =
    ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$MC_PKG")))

fun launchMc(ctx: Context) {
    val i = ctx.packageManager.getLaunchIntentForPackage(MC_PKG)
    if (i != null) ctx.startActivity(i)
    else Toast.makeText(ctx, "ماين كرافت غير مثبتة", Toast.LENGTH_SHORT).show()
}

fun openWorldFile(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/octet-stream")
                .setPackage(MC_PKG).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    } catch (e: Exception) {
        Toast.makeText(ctx, "تعذّر فتح العالم في ماين كرافت", Toast.LENGTH_LONG).show()
    }
}

// ---------------- الحالة المشتركة ----------------

class UiState(val repo: ApkRepo, private val scope: CoroutineScope, private val snack: SnackbarHostState) {
    var items by mutableStateOf(repo.load())
    var busy by mutableStateOf<String?>(null)
    var installed by mutableStateOf<Pair<String, Long>?>(null)

    fun reload() { items = repo.load() }
    fun toast(m: String) { scope.launch { snack.showSnackbar(m) } }

    fun <T> work(label: String, block: () -> T, done: (T) -> Unit = {}) {
        scope.launch {
            busy = label
            val r = runCatching { withContext(Dispatchers.IO) { block() } }
            busy = null
            r.onSuccess(done).onFailure { toast("خطأ: ${it.message}") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    val ui = remember { UiState(ApkRepo(ctx), scope, snack).also { it.installed = installedVersion(ctx) } }
    var tab by remember { mutableIntStateOf(0) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) ui.installed = installedVersion(ctx)
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("مدير إصدارات ماين كرافت") }) },
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Text("📦") }, label = { Text("الإصدارات") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Text("💾") }, label = { Text("العوالم") })
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp)) {
            ui.busy?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp))
            }
            if (tab == 0) VersionsTab(ui) else BackupTab(ui)
        }
    }
}

// ---------------- تبويب الإصدارات ----------------

@Composable
fun VersionsTab(ui: UiState) {
    val ctx = LocalContext.current
    var filter by remember { mutableStateOf<String?>(null) }
    var pendingType by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<ApkEntry?>(null) }
    var noteFor by remember { mutableStateOf<ApkEntry?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            ui.work("جارٍ استيراد ${uris.size} ملف (قد يأخذ وقتًا)...", { ui.repo.importMany(uris) }) { results ->
                ui.reload()
                val ok = results.mapNotNull { it.getOrNull() }
                val bad = results.mapNotNull { it.exceptionOrNull()?.message }
                if (ok.size == 1 && uris.size == 1) pendingType = ok[0].id
                ui.toast(buildString {
                    append("تمت إضافة ${ok.size}")
                    if (bad.isNotEmpty()) append("، تعذّر ${bad.size}: ${bad.first()}")
                })
            }
        }
    }

    val inst = ui.installed
    Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (inst != null) "النسخة المثبتة: ${inst.first}  (code ${inst.second})" else "ماين كرافت غير مثبتة",
                Modifier.weight(1f), style = MaterialTheme.typography.titleSmall
            )
            if (inst != null) Button({ launchMc(ctx) }) { Text("تشغيل") }
        }
    }

    Button(
        onClick = { picker.launch(arrayOf("*/*")) },
        modifier = Modifier.fillMaxWidth()
    ) { Text("إضافة ملفات APK من جهازي (عدة ملفات)") }

    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(filter == null, { filter = null }, { Text("الكل") })
        TYPES.forEach { (k, v) -> FilterChip(filter == k, { filter = k }, { Text(v) }) }
    }

    val shown = ui.items.filter { filter == null || it.type == filter }.sortedByDescending { it.versionCode }
    if (shown.isEmpty()) Text("لا توجد إصدارات بعد. أضف ملفات APK التي تملكها.")

    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(shown, key = { it.id }) { e ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        e.versionName + if (inst?.second == e.versionCode) "  ✓ مثبّتة" else "",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text("${TYPES[e.type]} • ${e.sizeMb} MB • code ${e.versionCode}", style = MaterialTheme.typography.bodySmall)
                    if (e.note.isNotBlank()) Text("📝 ${e.note}", style = MaterialTheme.typography.bodyMedium)
                    val pad = PaddingValues(horizontal = 8.dp)
                    Row {
                        TextButton({ confirm = e }, contentPadding = pad) { Text("تثبيت") }
                        TextButton({ noteFor = e }, contentPadding = pad) { Text("ملاحظة") }
                        TextButton({ pendingType = e.id }, contentPadding = pad) { Text("النوع") }
                        TextButton({ ui.repo.delete(e.id); ui.reload() }, contentPadding = pad) { Text("حذف") }
                    }
                }
            }
        }
    }

    pendingType?.let { id ->
        AlertDialog(
            onDismissRequest = { pendingType = null },
            confirmButton = {},
            title = { Text("نوع هذا الإصدار") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TYPES.forEach { (k, v) ->
                        Button({ ui.repo.setType(id, k); ui.reload(); pendingType = null }, Modifier.fillMaxWidth()) { Text(v) }
                    }
                }
            }
        )
    }

    noteFor?.let { e ->
        var text by remember(e.id) { mutableStateOf(e.note) }
        AlertDialog(
            onDismissRequest = { noteFor = null },
            title = { Text("ملاحظة على ${e.versionName}") },
            text = {
                OutlinedTextField(
                    text, { text = it }, Modifier.fillMaxWidth(),
                    placeholder = { Text("مثلاً: يشتغل عليه المود الفلاني") }
                )
            },
            confirmButton = { TextButton({ ui.repo.setNote(e.id, text); ui.reload(); noteFor = null }) { Text("حفظ") } },
            dismissButton = { TextButton({ noteFor = null }) { Text("إلغاء") } }
        )
    }

    confirm?.let { e ->
        val downgrade = inst != null && e.versionCode < inst.second
        val savedWorlds = ui.repo.worlds().size
        val prefs = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        val hasFolder = prefs.getString("worlds", null) != null
        var ack by remember(e.id) { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("تثبيت ${e.versionName}") },
            text = {
                if (downgrade) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("هذا إصدار أقدم من المثبّت. أندرويد لا يسمح بالرجوع مع الاحتفاظ بالبيانات، فحذف ماين كرافت يمسح عوالمها غير المحفوظة.")
                        Text(
                            if (savedWorlds > 0) "عوالم محفوظة في التطبيق: $savedWorlds ✓"
                            else "⚠ ما عندك أي عالم محفوظ. صدّر عوالمك من ماين كرافت واحفظها من تبويب «العوالم»."
                        )
                        if (hasFolder) Text("سيتم نسخ احتياطي تلقائي لمجلد العوالم قبل الحذف.")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(ack, { ack = it })
                            Text("تأكدت من حفظ عوالمي")
                        }
                    }
                } else {
                    Text("سيتم فتح شاشة التثبيت. بياناتك تبقى كما هي.")
                }
            },
            confirmButton = {
                Row {
                    if (downgrade) {
                        TextButton(enabled = ack, onClick = {
                            val w = prefs.getString("worlds", null)
                            if (w != null) {
                                ui.work("نسخ احتياطي تلقائي قبل الحذف...", { runCatching { ui.repo.backupWorlds(Uri.parse(w)) }.isSuccess }) { ok ->
                                    if (!ok) ui.toast("تعذّر النسخ التلقائي")
                                    uninstallMc(ctx)
                                }
                            } else {
                                uninstallMc(ctx)
                            }
                        }) { Text("حذف الحالية") }
                    }
                    TextButton(enabled = !downgrade || ack, onClick = { installApk(ctx, ui.repo.file(e)); confirm = null }) { Text("تثبيت") }
                }
            },
            dismissButton = { TextButton({ confirm = null }) { Text("إلغاء") } }
        )
    }
}

// ---------------- تبويب العوالم والنسخ الاحتياطي ----------------

@Composable
fun BackupTab(ui: UiState) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    var worlds by remember { mutableStateOf(prefs.getString("worlds", null)) }
    var backups by remember { mutableStateOf(ui.repo.backups()) }
    var vault by remember { mutableStateOf(ui.repo.worlds()) }
    var restoreFile by remember { mutableStateOf<File?>(null) }

    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            prefs.edit().putString("worlds", uri.toString()).apply()
            worlds = uri.toString()
        }
    }
    val pickWorlds = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            ui.work("جارٍ حفظ العوالم...", { ui.repo.importWorlds(uris) }) { n ->
                vault = ui.repo.worlds(); ui.toast("تم حفظ $n عالم ✓")
            }
        }
    }

    val hint = DocumentsContract.buildDocumentUri(
        "com.android.externalstorage.documents",
        "primary:Android/data/com.mojang.minecraftpe/files/games/com.mojang/minecraftWorlds"
    )

    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("عوالمي المحفوظة (.mcworld)", style = MaterialTheme.typography.titleMedium)
                    Text("هذي الطريقة المناسبة لأندرويد 13 وأحدث:\n1) في ماين كرافت: تعديل العالم ← تصدير.\n2) احفظ الملف هنا. يبقى محفوظًا حتى لو انحذفت ماين كرافت.\n3) بعد تغيير الإصدار اضغط «فتح» على كل عالم لاستعادته.")
                    Button({ pickWorlds.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("حفظ عوالم .mcworld في التطبيق") }
                }
            }
        }
        if (vault.isEmpty()) item { Text("لا توجد عوالم محفوظة بعد.") }
        items(vault, key = { it.name }) { f ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(f.name); Text("${f.length() / 1_000_000} MB", style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton({ openWorldFile(ctx, f) }) { Text("فتح في ماين كرافت") }
                        TextButton({ f.delete(); vault = ui.repo.worlds() }) { Text("حذف") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("نسخ احتياطي لمجلد العوالم (أندرويد 12 وأقل)", style = MaterialTheme.typography.titleMedium)
                    Text("على أندرويد 13 وأحدث يمنع النظام اختيار هذا المجلد، فاستخدم الخزنة اللي فوق.")
                    Button({ pickFolder.launch(hint) }, Modifier.fillMaxWidth()) { Text("اختيار مجلد العوالم") }
                    Button(
                        enabled = worlds != null,
                        onClick = {
                            ui.work("جارٍ النسخ الاحتياطي...", { ui.repo.backupWorlds(Uri.parse(worlds!!)) }) {
                                backups = ui.repo.backups(); ui.toast("تم النسخ الاحتياطي ✓")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("نسخ احتياطي الآن") }
                }
            }
        }
        if (backups.isNotEmpty()) item { Text("نسخ المجلد المحفوظة", style = MaterialTheme.typography.titleMedium) }
        items(backups, key = { it.name }) { f ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(f.name); Text("${f.length() / 1_000_000} MB", style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton({ restoreFile = f }, enabled = worlds != null) { Text("استعادة") }
                        TextButton({ f.delete(); backups = ui.repo.backups() }) { Text("حذف") }
                    }
                }
            }
        }
    }

    restoreFile?.let { f ->
        AlertDialog(
            onDismissRequest = { restoreFile = null },
            title = { Text("استعادة العوالم؟") },
            text = { Text("ستُكتب العوالم من ${f.name} فوق الموجودة بنفس الاسم.") },
            confirmButton = {
                TextButton({
                    restoreFile = null
                    ui.work("جارٍ الاستعادة...", { ui.repo.restore(f, Uri.parse(worlds!!)) }) { ui.toast("تمت الاستعادة ✓") }
                }) { Text("استعادة") }
            },
            dismissButton = { TextButton({ restoreFile = null }) { Text("إلغاء") } }
        )
    }
}
