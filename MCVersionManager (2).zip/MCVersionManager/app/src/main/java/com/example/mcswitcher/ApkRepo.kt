package com.example.mcswitcher

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.pm.PackageInfoCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

const val MC_PKG = "com.mojang.minecraftpe"

val TYPES = linkedMapOf(
    "release" to "أصلي",
    "beta" to "تجريبي",
    "old" to "قديم"
)

data class ApkEntry(
    val id: String,
    val versionName: String,
    val versionCode: Long,
    val type: String,
    val sizeMb: Long,
    val note: String = ""
)

class ApkRepo(private val ctx: Context) {
    private val apkDir = File(ctx.filesDir, "apks").apply { mkdirs() }
    private val backupDir = File(ctx.filesDir, "backups").apply { mkdirs() }
    private val index = File(ctx.filesDir, "library.json")

    fun file(e: ApkEntry) = File(apkDir, "${e.id}.apk")

    fun load(): List<ApkEntry> {
        if (!index.exists()) return emptyList()
        return runCatching {
            val arr = JSONArray(index.readText())
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                ApkEntry(
                    o.getString("id"), o.getString("name"), o.getLong("code"),
                    o.getString("type"), o.getLong("mb"), o.optString("note", "")
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun save(list: List<ApkEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.versionName)
                .put("code", it.versionCode).put("type", it.type).put("mb", it.sizeMb).put("note", it.note))
        }
        index.writeText(arr.toString())
    }

    /** ينسخ ملف APK إلى مخزن التطبيق ويتحقق أنه ماين كرافت. يعمل في خيط خلفي. */
    fun importApk(uri: Uri): Result<ApkEntry> {
        val id = UUID.randomUUID().toString()
        val f = File(apkDir, "$id.apk")
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { i ->
                f.outputStream().use { o -> i.copyTo(o) }
            } ?: error("تعذّر فتح الملف")
            val info = ctx.packageManager.getPackageArchiveInfo(f.path, 0)
            if (info == null || info.packageName != MC_PKG) {
                f.delete()
                return Result.failure(IllegalArgumentException("هذا الملف ليس APK لماين كرافت"))
            }
            val code = PackageInfoCompat.getLongVersionCode(info)
            val list = load()
            if (list.any { it.versionCode == code }) {
                f.delete()
                return Result.failure(IllegalArgumentException("هذا الإصدار موجود مسبقًا"))
            }
            val entry = ApkEntry(id, info.versionName ?: "?", code, "release", f.length() / 1_000_000)
            save(list + entry)
            Result.success(entry)
        } catch (e: Exception) {
            f.delete()
            Result.failure(e)
        }
    }

    fun setType(id: String, type: String) = save(load().map { if (it.id == id) it.copy(type = type) else it })

    fun delete(id: String) {
        File(apkDir, "$id.apk").delete()
        save(load().filter { it.id != id })
    }

    fun setNote(id: String, note: String) =
        save(load().map { if (it.id == id) it.copy(note = note.trim()) else it })

    /** يستورد عدة ملفات APK دفعة وحدة، ويرجع نتيجة كل ملف. */
    fun importMany(uris: List<Uri>): List<Result<ApkEntry>> = uris.map { importApk(it) }

    // ---------- خزنة عوالم .mcworld داخل التطبيق ----------

    private val worldDir = File(ctx.filesDir, "worlds").apply { mkdirs() }

    fun worlds(): List<File> = worldDir.listFiles()?.sortedBy { it.name.lowercase() } ?: emptyList()

    fun importWorlds(uris: List<Uri>): Int {
        var n = 0
        for (u in uris) {
            val raw = ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                ?: "world_${System.currentTimeMillis()}"
            var name = raw.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_")
            if (!name.endsWith(".mcworld", ignoreCase = true)) name += ".mcworld"
            var f = File(worldDir, name)
            if (f.exists()) f = File(worldDir, "${System.currentTimeMillis()}_$name")
            ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            if (f.exists() && f.length() > 0) n++
        }
        return n
    }

    // ---------- النسخ الاحتياطي للعوالم ----------

    fun backups(): List<File> =
        backupDir.listFiles { f -> f.extension == "zip" }?.sortedByDescending { it.name } ?: emptyList()

    fun backupWorlds(treeUri: Uri): File {
        val root = DocumentFile.fromTreeUri(ctx, treeUri) ?: error("لا يوجد وصول للمجلد، اختره من جديد")
        require(root.canRead()) { "لا يوجد وصول للمجلد، اختره من جديد" }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val out = File(backupDir, "worlds_$stamp.zip")
        var count = 0
        ZipOutputStream(out.outputStream().buffered()).use { zos ->
            fun walk(dir: DocumentFile, prefix: String) {
                for (f in dir.listFiles()) {
                    val name = prefix + (f.name ?: continue)
                    if (f.isDirectory) walk(f, "$name/") else {
                        zos.putNextEntry(ZipEntry(name))
                        ctx.contentResolver.openInputStream(f.uri)?.use { it.copyTo(zos) }
                        zos.closeEntry()
                        count++
                    }
                }
            }
            walk(root, "")
        }
        if (count == 0) { out.delete(); error("المجلد فارغ، تأكد أنك اخترت minecraftWorlds") }
        return out
    }

    fun restore(zip: File, treeUri: Uri) {
        val root = DocumentFile.fromTreeUri(ctx, treeUri) ?: error("لا توجد صلاحية كتابة على المجلد")
        require(root.canWrite()) { "لا توجد صلاحية كتابة على المجلد" }
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                if (!e.isDirectory && !e.name.contains("..")) {
                    val parts = e.name.split("/")
                    var dir: DocumentFile = root
                    for (p in parts.dropLast(1)) dir = dir.findFile(p) ?: dir.createDirectory(p)!!
                    val name = parts.last()
                    dir.findFile(name)?.delete()
                    val target = dir.createFile("application/octet-stream", name)!!
                    ctx.contentResolver.openOutputStream(target.uri)?.use { zis.copyTo(it) }
                }
                zis.closeEntry()
                e = zis.nextEntry
            }
        }
    }
}
