#!/bin/bash
# شغّله من داخل مجلد المشروع: bash setup.sh
set -e
flutter create --platforms=android --project-name minecraft_manager .
M=android/app/src/main/AndroidManifest.xml
python3 - <<'PY'
p="android/app/src/main/AndroidManifest.xml"
s=open(p).read()
perms='''    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES"/>
'''
if "MANAGE_EXTERNAL_STORAGE" not in s:
    s=s.replace("<application",perms+"    <application",1)
    s=s.replace("<application","<application android:requestLegacyExternalStorage=\"true\"",1)
open(p,"w").write(s)
PY
flutter pub get
echo "تم. شغّل: flutter run   أو   flutter build apk --release"
