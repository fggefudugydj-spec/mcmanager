import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../models/minecraft_version.dart';
import '../services/apk_installer.dart';
import '../services/backup_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final BackupService _backupService = BackupService();
  final ApkInstaller _apkInstaller = ApkInstaller();

  MinecraftVersion? _selectedVersion;
  String? _apkPath;
  bool _busy = false;

  Future<void> _requestPermissions() async {
    await [
      Permission.storage,
      Permission.manageExternalStorage,
    ].request();
  }

  Future<void> _pickApk() async {
    await _requestPermissions();

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ["apk"],
    );

    if (result != null && result.files.single.path != null) {
      setState(() {
        _apkPath = result.files.single.path;
      });
    }
  }

  Future<void> _backupWorlds() async {
    await _requestPermissions();
    setState(() => _busy = true);

    try {
      final path = await _backupService.backupWorlds();

      if (!mounted) return;
      _showMessage("تم إنشاء نسخة احتياطية في:\n$path");
    } catch (error) {
      if (!mounted) return;
      _showMessage(error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _installSelectedVersion() async {
    if (_apkPath == null) {
      _showMessage("اختر ملف APK أولًا.");
      return;
    }

    final confirmed = await _showConfirmDialog(
      "سيتم فتح مثبّت أندرويد لتثبيت الملف المختار.\n"
      "تأكد من أخذ نسخة احتياطية للعوالم قبل التثبيت.",
    );

    if (!confirmed) return;

    setState(() => _busy = true);

    try {
      await _apkInstaller.installApk(_apkPath!);
    } catch (error) {
      if (!mounted) return;
      _showMessage(error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<bool> _showConfirmDialog(String message) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("تأكيد"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("إلغاء"),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text("متابعة"),
          ),
        ],
      ),
    );

    return result ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("مدير نسخ ماينكرافت"),
        centerTitle: true,
      ),
      body: _busy
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "اختر الإصدار",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 12),
                        ...minecraftVersions.map((version) {
                          return RadioListTile<String>(
                            title: Text(version.name),
                            subtitle: Text(
                              "${version.releaseDate}\n${version.notes}",
                            ),
                            value: version.id,
                            groupValue: _selectedVersion?.id,
                            onChanged: (value) {
                              setState(() {
                                _selectedVersion = minecraftVersions
                                    .firstWhere((v) => v.id == value);
                              });
                            },
                          );
                        }),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: _backupWorlds,
                  icon: const Icon(Icons.backup),
                  label: const Text("نسخ احتياطي للعوالم"),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: _pickApk,
                  icon: const Icon(Icons.folder_open),
                  label: Text(
                    _apkPath == null
                        ? "اختر ملف APK"
                        : "الملف: ${_apkPath!.split('/').last}",
                  ),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: _installSelectedVersion,
                  icon: const Icon(Icons.install_mobile),
                  label: const Text("تثبيت الإصدار المختار"),
                ),
                const SizedBox(height: 24),
                const Text(
                  "تنبيه:\n"
                  "• لا تفتح عالمًا على إصدار أحدث ثم تحاول فتحه على إصدار أقدم.\n"
                  "• خذ نسخة احتياطية قبل كل تغيير.\n"
                  "• استخدم ملفات APK من مصدر موثوق فقط.",
                  style: TextStyle(color: Colors.redAccent),
                ),
              ],
            ),
    );
  }
}
