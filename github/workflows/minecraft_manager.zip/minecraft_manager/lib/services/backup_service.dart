import 'dart:io';

import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';

class BackupService {
  Future<String> backupWorlds() async {
    final docs = await getApplicationDocumentsDirectory();
    final backupRoot = Directory("${docs.path}/minecraft_backups");

    if (!await backupRoot.exists()) {
      await backupRoot.create(recursive: true);
    }

    final stamp = DateFormat("yyyy-MM-dd_HH-mm-ss").format(DateTime.now());
    final backupDir = Directory("${backupRoot.path}/worlds_$stamp");
    await backupDir.create(recursive: true);

    final possiblePaths = [
      "/storage/emulated/0/games/com.mojang/minecraftWorlds",
      "/storage/emulated/0/Android/data/com.mojang.minecraftpe/files/games/com.mojang/minecraftWorlds",
    ];

    Directory? worldsDir;

    for (final path in possiblePaths) {
      final dir = Directory(path);

      if (await dir.exists()) {
        worldsDir = dir;
        break;
      }
    }

    if (worldsDir == null) {
      throw Exception("لم يتم العثور على مجلد العوالم. افتح ماينكرافت مرة واحدة ثم أعد المحاولة.");
    }

    final worlds = worldsDir.listSync();

    if (worlds.isEmpty) {
      throw Exception("لا توجد عوالم لعمل نسخة احتياطية لها.");
    }

    for (final world in worlds) {
      final name = world.path.split("/").last;
      final target = Directory("${backupDir.path}/$name");

      if (world is Directory) {
        await _copyDirectory(world, target);
      }
    }

    return backupDir.path;
  }

  Future<void> _copyDirectory(Directory source, Directory target) async {
    await target.create(recursive: true);

    await for (final entity in source.list()) {
      final newPath = "${target.path}/${entity.path.split("/").last}";

      if (entity is Directory) {
        await _copyDirectory(entity, Directory(newPath));
      } else if (entity is File) {
        await entity.copy(newPath);
      }
    }
  }
}
