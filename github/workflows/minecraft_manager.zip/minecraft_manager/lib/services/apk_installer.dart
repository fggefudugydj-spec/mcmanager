import 'dart:io';

import 'package:open_filex/open_filex.dart';

class ApkInstaller {
  Future<void> installApk(String apkPath) async {
    final file = File(apkPath);

    if (!await file.exists()) {
      throw Exception("ملف APK غير موجود.");
    }

    if (!apkPath.toLowerCase().endsWith(".apk")) {
      throw Exception("الملف المختار ليس ملف APK.");
    }

    final result = await OpenFilex.open(
      apkPath,
      type: "application/vnd.android.package-archive",
    );

    if (result.type.toString().contains("error")) {
      throw Exception("تعذر فتح مثبّت APK. تأكد من منح صلاحية تثبيت التطبيقات غير المعروفة.");
    }
  }
}
