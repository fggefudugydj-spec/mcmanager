class MinecraftVersion {
  final String id;
  final String name;
  final String releaseDate;
  final String notes;

  const MinecraftVersion({
    required this.id,
    required this.name,
    required this.releaseDate,
    required this.notes,
  });
}

const List<MinecraftVersion> minecraftVersions = [
  MinecraftVersion(
    id: "1.21",
    name: "Minecraft 1.21",
    releaseDate: "2024",
    notes: "Tricky Trials",
  ),
  MinecraftVersion(
    id: "1.20",
    name: "Minecraft 1.20",
    releaseDate: "2023",
    notes: "Trails & Tales",
  ),
  MinecraftVersion(
    id: "1.19",
    name: "Minecraft 1.19",
    releaseDate: "2022",
    notes: "The Wild Update",
  ),
];
