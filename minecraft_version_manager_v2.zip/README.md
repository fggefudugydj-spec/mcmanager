# مدير نسخ ماينكرافت - الإصدار 2

## الجديد مقارنة بالإصدار الأول
- يقرأ إصدار ماينكرافت المثبت فعليًا على الجوال ويقارنه بآخر إصدار (26.62).
- زر **تشغيل ماينكرافت** مباشرة من التطبيق.
- زر **تحديث من المتجر** يفتح صفحة اللعبة في Google Play.
- يفحص ملف APK قبل التثبيت: هل هو ماينكرافت؟ ما إصداره؟ هل يدعمه جهازك؟
- يكشف محاولة التراجع لإصدار أقدم ويعرض إزالة الحالي أولًا.
- يطلب صلاحية "تثبيت تطبيقات غير معروفة" تلقائيًا.
- استيراد ملفات .mcworld و .mcpack و .mcaddon إلى اللعبة.
- نسخ احتياطي بصيغة ZIP مع قائمة للاستعادة والحذف.
- واجهة عربية كاملة من اليمين لليسار، وتبويبات، ووضع ليلي.
- يتحدّث تلقائيًا عند الرجوع من المتجر أو المثبّت.

## خطوات التشغيل
1. أنشئ مشروعًا جديدًا:
   ```bash
   flutter create --org com.example minecraft_version_manager
   cd minecraft_version_manager
   ```
2. انسخ ملفات هذا المجلد فوق المشروع (استبدل الموجود):
   - `pubspec.yaml`
   - `lib/` كاملًا
   - `android/app/src/main/AndroidManifest.xml`
   - `android/app/src/main/res/xml/file_paths.xml`
   - `android/app/src/main/kotlin/com/example/minecraft_version_manager/MainActivity.kt`
3. في `android/app/build.gradle.kts` أضف في آخر الملف:
   ```kotlin
   dependencies {
       implementation("androidx.core:core-ktx:1.13.1")
   }
   ```
   وفي `defaultConfig` اجعل:
   ```kotlin
   minSdk = 23
   ```
   (إذا كان ملفك `build.gradle` القديم: `implementation "androidx.core:core-ktx:1.13.1"` و `minSdkVersion 23`)
4. شغّل:
   ```bash
   flutter pub get
   flutter run
   flutter build apk --release
   ```

## تحديث قائمة الإصدارات
عند صدور إصدار جديد عدّل `lib/models/minecraft_version.dart` وأضف الإصدار في أعلى القائمة.
أول إصدار غير تجريبي في القائمة يُعتبر "آخر إصدار".

## ملاحظات
- أحدث ماينكرافت يحتاج أندرويد 9 أو أحدث.
- في الإصدارات الحديثة تحفظ اللعبة العوالم داخلها؛ لذلك صدّر العالم من إعدادات العالم في اللعبة قبل إزالة اللعبة.
- التطبيق لا يحمّل ولا يوزّع ملفات APK؛ استخدم مصدرًا موثوقًا أو متجر Google Play.
