package com.example.minecraft_version_manager

import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    private val channelName = "mc_manager/native"
    private val mcPackage = "com.mojang.minecraftpe"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "getDeviceInfo" -> result.success(
                            mapOf(
                                "sdkInt" to Build.VERSION.SDK_INT,
                                "release" to Build.VERSION.RELEASE,
                                "abi" to (Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown")
                            )
                        )
                        "getInstalledInfo" -> result.success(getInstalledInfo())
                        "launchMinecraft" -> result.success(launchMinecraft())
                        "openStore" -> { openStore(); result.success(true) }
                        "openAppSettings" -> { openMinecraftSettings(); result.success(true) }
                        "uninstallMinecraft" -> { uninstallMinecraft(); result.success(true) }
                        "getApkInfo" -> result.success(getApkInfo(call.argument<String>("path")!!))
                        "canInstallApks" -> result.success(canInstallApks())
                        "openInstallPermission" -> { openInstallPermission(); result.success(true) }
                        "installApk" -> { installApk(call.argument<String>("path")!!); result.success(true) }
                        "openWithMinecraft" -> {
                            openWithMinecraft(call.argument<String>("path")!!)
                            result.success(true)
                        }
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("NATIVE_ERROR", e.message ?: e.toString(), null)
                }
            }
    }

    @Suppress("DEPRECATION")
    private fun packageInfo(name: String): PackageInfo? = try {
        if (Build.VERSION.SDK_INT >= 33) {
            packageManager.getPackageInfo(name, PackageManager.PackageInfoFlags.of(0))
        } else {
            packageManager.getPackageInfo(name, 0)
        }
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    @Suppress("DEPRECATION")
    private fun versionCodeOf(info: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()

    private fun getInstalledInfo(): Map<String, Any?> {
        val info = packageInfo(mcPackage) ?: return mapOf("installed" to false)
        return mapOf(
            "installed" to true,
            "versionName" to info.versionName,
            "versionCode" to versionCodeOf(info),
            "lastUpdate" to info.lastUpdateTime
        )
    }

    private fun launchMinecraft(): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(mcPackage) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return true
    }

    private fun openStore() {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$mcPackage"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$mcPackage")
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun openMinecraftSettings() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$mcPackage"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    @Suppress("DEPRECATION")
    private fun uninstallMinecraft() {
        startActivity(
            Intent(Intent.ACTION_DELETE, Uri.parse("package:$mcPackage"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    @Suppress("DEPRECATION")
    private fun getApkInfo(path: String): Map<String, Any?> {
        val info = if (Build.VERSION.SDK_INT >= 33) {
            packageManager.getPackageArchiveInfo(path, PackageManager.PackageInfoFlags.of(0))
        } else {
            packageManager.getPackageArchiveInfo(path, 0)
        } ?: return mapOf("valid" to false)

        return mapOf(
            "valid" to true,
            "packageName" to info.packageName,
            "versionName" to info.versionName,
            "versionCode" to versionCodeOf(info),
            "minSdk" to if (Build.VERSION.SDK_INT >= 24) info.applicationInfo?.minSdkVersion else null
        )
    }

    private fun canInstallApks(): Boolean =
        if (Build.VERSION.SDK_INT >= 26) packageManager.canRequestPackageInstalls() else true

    private fun openInstallPermission() {
        if (Build.VERSION.SDK_INT >= 26) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:$packageName")
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun uriFor(path: String): Uri =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", File(path))

    private fun installApk(path: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uriFor(path), "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intent)
    }

    /** يفتح ملف .mcworld أو .mcpack أو .mcaddon داخل ماينكرافت لاستيراده */
    private fun openWithMinecraft(path: String) {
        val uri = uriFor(path)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            setPackage(mcPackage)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        grantUriPermission(mcPackage, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(intent)
    }
}
