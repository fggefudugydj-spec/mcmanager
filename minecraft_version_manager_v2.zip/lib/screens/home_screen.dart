import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/minecraft_version.dart';
import '../services/backup_service.dart';
import '../services/native_bridge.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  final _native = NativeBridge();
  final _backup = BackupService();

  int _tab = 0;
  bool _busy = false;
  InstalledInfo? _installed;
  DeviceInfo? _device;
  List<File> _backups = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // عند الرجوع من المتجر أو المثبّت نحدّث الحالة تلقائيًا
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    try {
      final results = await Future.wait([
        _native.installedMinecraft(),
        _native.deviceInfo(),
        _backup.listBackups(),
      ]);
      if (!mounted) return;
      setState(() {
        _installed = results[0] as InstalledInfo;
        _device = results[1] as DeviceInfo;
        _backups = results[2] as List<File>;
      });
    } catch (e) {
      _toast("خطأ في قراءة الحالة: $e");
    }
  }

  Future<void> _run(Future<void> Function() job) async {
    setState(() => _busy = true);
    try {
      await job();
    } catch (e) {
      _toast(e.toString().replaceFirst("Exception: ", ""));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 5)));
  }

  Future<bool> _confirm(String title, String body, {String ok = "متابعة"}) async {
    final r = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text("إلغاء")),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(ok)),
        ],
      ),
    );
    return r ?? false;
  }

  // ---------------- الحالة ----------------

  bool get _isLatest {
    final v = _installed?.versionName;
    if (v == null) return false;
    return compareVersions(v, latestRelease.internal) >= 0;
  }

  bool get _deviceSupportsLatest => (_device?.sdkInt ?? 99) >= latestRelease.minAndroidSdk;

  // ---------------- الإجراءات ----------------

  Future<void> _play() => _run(() async {
        final ok = await _native.launchMinecraft();
        if (!ok) _toast("ماينكرافت غير مثبتة على الجهاز.");
      });

  Future<void> _installApk() => _run(() async {
        final picked = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: ["apk"],
        );
        final path = picked?.files.single.path;
        if (path == null) return;

        final apk = await _native.apkInfo(path);
        if (!apk.valid) throw Exception("الملف تالف أو ليس APK صالحًا.");
        if (!apk.isMinecraft) {
          throw Exception("هذا الملف ليس ماينكرافت (${apk.packageName}).");
        }
        if (apk.minSdk != null && _device != null && apk.minSdk! > _device!.sdkInt) {
          throw Exception("هذا الإصدار يحتاج أندرويد أحدث من جهازك.");
        }

        final apkVer = apk.versionName ?? "?";
        final cur = _installed?.versionName;

        // تثبيت إصدار أقدم يتطلب إزالة الحالي أولًا
        if (_installed?.installed == true && cur != null && compareVersions(apkVer, cur) < 0) {
          final go = await _confirm(
            "إصدار أقدم",
            "الملف: ${displayVersion(apkVer)}\nالمثبت: ${displayVersion(cur)}\n\n"
                "أندرويد لا يسمح بالتثبيت فوق إصدار أحدث. يجب إزالة ماينكرافت أولًا، "
                "وقد تُحذف العوالم المحفوظة داخل التطبيق.\n\n"
                "صدّر عوالمك أو خذ نسخة احتياطية قبل المتابعة.\n"
                "بعد الإزالة ارجع واضغط تثبيت APK مرة أخرى.",
            ok: "إزالة الحالي",
          );
          if (go) await _native.uninstallMinecraft();
          return;
        }

        if (!await _native.canInstallApks()) {
          _toast("فعّل صلاحية \"تثبيت تطبيقات غير معروفة\" ثم أعد المحاولة.");
          await _native.openInstallPermission();
          return;
        }

        final go = await _confirm(
          "تثبيت ماينكرافت ${displayVersion(apkVer)}",
          "سيتم فتح مثبّت أندرويد.\nاستخدم ملفات من مصدر موثوق فقط.",
          ok: "تثبيت",
        );
        if (go) await _native.installApk(path);
      });

  Future<void> _importToMinecraft() => _run(() async {
        final picked = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: ["mcworld", "mcpack", "mcaddon", "mctemplate"],
        );
        final path = picked?.files.single.path;
        if (path == null) return;
        await _native.openWithMinecraft(path);
      });

  Future<void> _makeBackup() => _run(() async {
        final f = await _backup.backupWorlds();
        _toast("تم الحفظ: ${f.path.split('/').last}");
        await _refresh();
      });

  Future<void> _restore(File f) async {
    final go = await _confirm(
      "استعادة النسخة",
      "سيتم استبدال العوالم بنفس الاسم بمحتوى هذه النسخة.",
      ok: "استعادة",
    );
    if (!go) return;
    await _run(() async {
      await _backup.restore(f);
      _toast("تمت الاستعادة.");
    });
  }

  // ---------------- الواجهة ----------------

  @override
  Widget build(BuildContext context) {
    final pages = [_homeTab(), _versionsTab(), _toolsTab()];
    return Scaffold(
      appBar: AppBar(
        title: const Text("مدير نسخ ماينكرافت"),
        centerTitle: true,
        actions: [IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh))],
      ),
      body: Stack(
        children: [
          RefreshIndicator(onRefresh: _refresh, child: pages[_tab]),
          if (_busy)
            const ColoredBox(
              color: Colors.black26,
              child: Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.sports_esports), label: "الرئيسية"),
          NavigationDestination(icon: Icon(Icons.list_alt), label: "الإصدارات"),
          NavigationDestination(icon: Icon(Icons.build), label: "الأدوات"),
        ],
      ),
    );
  }

  Widget _homeTab() {
    final cs = Theme.of(context).colorScheme;
    final inst = _installed;
    final installed = inst?.installed == true;
    final ver = installed ? displayVersion(inst!.versionName ?? "?") : "غير مثبتة";

    final statusText = !installed
        ? "ماينكرافت غير مثبتة"
        : _isLatest
            ? "لديك آخر إصدار"
            : "يتوفر تحديث إلى ${latestRelease.name}";
    final statusColor = !installed ? cs.error : (_isLatest ? Colors.green : Colors.orange);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Icon(Icons.grass, size: 56, color: cs.primary),
                const SizedBox(height: 8),
                Text("الإصدار المثبت", style: TextStyle(color: cs.outline)),
                Text(ver, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Chip(
                  avatar: Icon(Icons.circle, size: 12, color: statusColor),
                  label: Text(statusText),
                ),
                const SizedBox(height: 4),
                Text(
                  "آخر إصدار رسمي: ${latestRelease.name} (${latestRelease.date})",
                  style: TextStyle(color: cs.outline, fontSize: 13),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(56)),
          onPressed: installed ? _play : null,
          icon: const Icon(Icons.play_arrow),
          label: const Text("تشغيل ماينكرافت", style: TextStyle(fontSize: 18)),
        ),
        const SizedBox(height: 12),
        FilledButton.tonalIcon(
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
          onPressed: () => _run(_native.openStore),
          icon: const Icon(Icons.system_update),
          label: Text(installed && !_isLatest
              ? "تحديث إلى ${latestRelease.name} من المتجر"
              : "فتح ماينكرافت في المتجر"),
        ),
        if (installed) ...[
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => _run(_native.openMinecraftSettings),
            icon: const Icon(Icons.settings),
            label: const Text("إعدادات اللعبة في النظام (مسح الذاكرة المؤقتة)"),
          ),
        ],
        const SizedBox(height: 16),
        if (_device != null)
          Card(
            color: _deviceSupportsLatest ? null : cs.errorContainer,
            child: ListTile(
              leading: const Icon(Icons.phone_android),
              title: Text("أندرويد ${_device!.release} • ${_device!.abi}"),
              subtitle: Text(_deviceSupportsLatest
                  ? "جهازك يدعم آخر إصدار (يتطلب أندرويد 9 أو أحدث)."
                  : "آخر إصدار يحتاج أندرويد 9 أو أحدث، جهازك لا يدعمه."),
            ),
          ),
      ],
    );
  }

  Widget _versionsTab() {
    final cur = _installed?.versionName;
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        for (final v in minecraftVersions)
          Card(
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: v.isBeta ? Colors.orange.shade100 : Colors.green.shade100,
                child: Icon(v.isBeta ? Icons.science : Icons.verified,
                    color: v.isBeta ? Colors.orange : Colors.green),
              ),
              title: Text("Minecraft ${v.name}",
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text("${v.title}\n${v.date} • ${v.typeLabel}"),
              isThreeLine: true,
              trailing: cur != null && _sameBranch(cur, v)
                  ? const Chip(label: Text("مثبت"))
                  : null,
            ),
          ),
        const Padding(
          padding: EdgeInsets.all(12),
          child: Text(
            "للحصول على آخر إصدار استخدم زر التحديث من المتجر. "
            "للإصدارات القديمة ثبّت ملف APK من تبويب الأدوات.",
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }

  /// 1.26.62.1 تطابق 26.62 ، و 1.21.50 تطابق 1.21
  bool _sameBranch(String installed, MinecraftVersion v) {
    final a = installed.split(".");
    final b = v.internal.split(".");
    final major = int.tryParse(b.length > 1 ? b[1] : "0") ?? 0;
    final n = major >= 26 ? b.length : 2;
    if (a.length < n) return false;
    for (var i = 0; i < n; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }

  Widget _toolsTab() {
    final fmt = DateFormat("yyyy/MM/dd HH:mm");
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _toolButton(Icons.install_mobile, "تثبيت ملف APK",
            "يفحص الإصدار قبل التثبيت ويحذّرك من التراجع", _installApk),
        _toolButton(Icons.file_open, "استيراد عالم أو إضافة",
            "يفتح ملفات .mcworld و .mcpack و .mcaddon في ماينكرافت", _importToMinecraft),
        _toolButton(Icons.backup, "نسخ احتياطي للعوالم",
            "يحفظ العوالم في ملف ZIP واحد", _makeBackup),
        const SizedBox(height: 16),
        Text("النسخ الاحتياطية (${_backups.length})",
            style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        if (_backups.isEmpty)
          const Text("لا توجد نسخ احتياطية بعد.")
        else
          for (final f in _backups)
            Card(
              child: ListTile(
                leading: const Icon(Icons.folder_zip),
                title: Text(f.path.split("/").last),
                subtitle: Text(
                    "${fmt.format(f.lastModifiedSync())} • ${(f.lengthSync() / 1048576).toStringAsFixed(1)} MB"),
                trailing: PopupMenuButton<String>(
                  onSelected: (a) async {
                    if (a == "restore") await _restore(f);
                    if (a == "delete") {
                      await _backup.delete(f);
                      await _refresh();
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: "restore", child: Text("استعادة")),
                    PopupMenuItem(value: "delete", child: Text("حذف")),
                  ],
                ),
              ),
            ),
        const SizedBox(height: 16),
        Text(
          "تنبيه:\n"
          "• لا تفتح عالمًا على إصدار أحدث ثم تعيده لإصدار أقدم؛ قد يتلف.\n"
          "• في الإصدارات الحديثة العوالم محفوظة داخل اللعبة، فاستخدم تصدير العالم من الإعدادات.\n"
          "• استخدم ملفات APK من مصدر موثوق فقط.",
          style: TextStyle(color: Theme.of(context).colorScheme.error),
        ),
      ],
    );
  }

  Widget _toolButton(IconData icon, String title, String sub, VoidCallback onTap) {
    return Card(
      child: ListTile(
        leading: Icon(icon, size: 32),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(sub),
        trailing: const Icon(Icons.chevron_left),
        onTap: onTap,
      ),
    );
  }
}
