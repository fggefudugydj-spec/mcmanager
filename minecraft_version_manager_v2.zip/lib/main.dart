import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/home_screen.dart';

void main() => runApp(const McManagerApp());

class McManagerApp extends StatelessWidget {
  const McManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF3C8527);
    return MaterialApp(
      title: "مدير نسخ ماينكرافت",
      debugShowCheckedModeBanner: false,
      locale: const Locale("ar"),
      supportedLocales: const [Locale("ar"), Locale("en")],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.dark),
      ),
      home: const HomeScreen(),
    );
  }
}
