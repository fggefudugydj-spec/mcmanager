enum VersionType { release, hotfix, beta }

class MinecraftVersion {
  /// الرقم الظاهر للاعب مثل 26.62
  final String name;

  /// الرقم الداخلي في أندرويد مثل 1.26.62
  final String internal;
  final String title;
  final String date;
  final VersionType type;
  final int minAndroidSdk;

  const MinecraftVersion({
    required this.name,
    required this.internal,
    required this.title,
    required this.date,
    this.type = VersionType.release,
    this.minAndroidSdk = 28,
  });

  bool get isBeta => type == VersionType.beta;

  String get typeLabel => switch (type) {
        VersionType.release => "إصدار رسمي",
        VersionType.hotfix => "إصلاح",
        VersionType.beta => "تجريبي",
      };
}

/// عدّل هذه القائمة عند صدور تحديث جديد.
/// مصدر الأرقام: minecraft.wiki (آخر تحديث للقائمة: 9 نوفمبر 2026)
const List<MinecraftVersion> minecraftVersions = [
  MinecraftVersion(
    name: "26.70.23",
    internal: "1.26.70.23",
    title: "بيتا 26.70",
    date: "3 نوفمبر 2026",
    type: VersionType.beta,
  ),
  MinecraftVersion(
    name: "26.62",
    internal: "1.26.62",
    title: "آخر إصدار رسمي",
    date: "6 نوفمبر 2026",
    type: VersionType.hotfix,
  ),
  MinecraftVersion(
    name: "26.60",
    internal: "1.26.60",
    title: "تحديث أكتوبر",
    date: "27 أكتوبر 2026",
  ),
  MinecraftVersion(
    name: "26.50",
    internal: "1.26.50",
    title: "Wilderness Bound",
    date: "15 سبتمبر 2026",
    minAndroidSdk: 26,
  ),
  MinecraftVersion(
    name: "1.21",
    internal: "1.21.0",
    title: "Tricky Trials",
    date: "2024",
    minAndroidSdk: 26,
  ),
  MinecraftVersion(
    name: "1.20",
    internal: "1.20.0",
    title: "Trails & Tales",
    date: "2023",
    minAndroidSdk: 21,
  ),
  MinecraftVersion(
    name: "1.19",
    internal: "1.19.0",
    title: "The Wild Update",
    date: "2022",
    minAndroidSdk: 21,
  ),
];

MinecraftVersion get latestRelease =>
    minecraftVersions.firstWhere((v) => !v.isBeta);

/// يقارن رقمين مثل 1.26.62.1 و 1.26.60
/// يرجع موجب إذا a أحدث، سالب إذا أقدم، صفر إذا متساويين.
int compareVersions(String a, String b) {
  List<int> parse(String v) => v
      .split(RegExp(r"[^0-9]+"))
      .where((p) => p.isNotEmpty)
      .map(int.parse)
      .toList();

  final pa = parse(a);
  final pb = parse(b);
  final len = pa.length > pb.length ? pa.length : pb.length;

  for (var i = 0; i < len; i++) {
    final x = i < pa.length ? pa[i] : 0;
    final y = i < pb.length ? pb[i] : 0;
    if (x != y) return x - y;
  }
  return 0;
}

/// يحوّل 1.26.62.1 إلى 26.62 للعرض
String displayVersion(String internal) {
  final parts = internal.split(".");
  if (parts.length >= 3 && parts[0] == "1") {
    final major = int.tryParse(parts[1]) ?? 0;
    if (major >= 26) return "${parts[1]}.${parts[2]}";
  }
  return internal;
}
