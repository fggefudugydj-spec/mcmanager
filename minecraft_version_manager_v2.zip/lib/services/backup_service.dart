import 'dart:io';

import 'package:archive/archive_io.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class BackupService {
  static const _worldPaths = [
    "/storage/emulated/0/games/com.mojang/minecraftWorlds",
    "/storage/emulated/0/Android/data/com.mojang.minecraftpe/files/games/com.mojang/minecraftWorlds",
  ];

  Future<bool> requestStorage() async {
    if (await Permission.manageExternalStorage.isGranted) return true;
    final manage = await Permission.manageExternalStorage.request();
    if (manage.isGranted) return true;
    final storage = await Permission.storage.request();
    return storage.isGranted;
  }

  Future<Directory?> findWorldsDir() async {
    for (final p in _worldPaths) {
      final d = Directory(p);
      try {
        if (await d.exists() && d.listSync().isNotEmpty) return d;
      } catch (_) {
        // مجلد محمي في أندرويد 11+
      }
    }
    return null;
  }

  Future<Directory> _backupRoot() async {
    final base = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
    final root = Directory("${base.path}/backups");
    if (!await root.exists()) await root.create(recursive: true);
    return root;
  }

  /// ينشئ ملف ZIP واحد لكل العوالم
  Future<File> backupWorlds() async {
    await requestStorage();
    final worlds = await findWorldsDir();
    if (worlds == null) {
      throw Exception(
        "لم يتم العثور على العوالم.\n"
        "في الإصدارات الحديثة تحفظ ماينكرافت العوالم داخل التطبيق. "
        "صدّر العالم من اللعبة (الإعدادات ← تصدير العالم) ثم استورده من هنا لاحقًا.",
      );
    }

    final root = await _backupRoot();
    final stamp = DateFormat("yyyy-MM-dd_HH-mm").format(DateTime.now());
    final zipPath = "${root.path}/worlds_$stamp.zip";

    await ZipFileEncoder().zipDirectoryAsync(worlds, filename: zipPath);
    return File(zipPath);
  }

  Future<List<File>> listBackups() async {
    final root = await _backupRoot();
    final files = root
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith(".zip"))
        .toList()
      ..sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
    return files;
  }

  Future<void> restore(File zip) async {
    await requestStorage();
    final target = await findWorldsDir() ?? Directory(_worldPaths.first);
    if (!await target.exists()) await target.create(recursive: true);
    // الملف المضغوط يحتوي مجلدات العوالم مباشرة
    await Future.sync(() => extractFileToDisk(zip.path, target.path));
  }

  Future<void> delete(File zip) => zip.delete();
}
