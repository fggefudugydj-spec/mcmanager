import 'package:flutter/services.dart';

class InstalledInfo {
  final bool installed;
  final String? versionName;
  final int? versionCode;

  const InstalledInfo({required this.installed, this.versionName, this.versionCode});
}

class ApkInfo {
  final bool valid;
  final String? packageName;
  final String? versionName;
  final int? minSdk;

  const ApkInfo({required this.valid, this.packageName, this.versionName, this.minSdk});

  bool get isMinecraft => packageName == "com.mojang.minecraftpe";
}

class DeviceInfo {
  final int sdkInt;
  final String release;
  final String abi;

  const DeviceInfo({required this.sdkInt, required this.release, required this.abi});
}

/// جسر بين Flutter وكود Kotlin في MainActivity
class NativeBridge {
  static const _ch = MethodChannel("mc_manager/native");

  Future<DeviceInfo> deviceInfo() async {
    final m = Map<String, dynamic>.from(await _ch.invokeMethod("getDeviceInfo"));
    return DeviceInfo(
      sdkInt: m["sdkInt"] as int,
      release: m["release"].toString(),
      abi: m["abi"].toString(),
    );
  }

  Future<InstalledInfo> installedMinecraft() async {
    final m = Map<String, dynamic>.from(await _ch.invokeMethod("getInstalledInfo"));
    return InstalledInfo(
      installed: m["installed"] == true,
      versionName: m["versionName"] as String?,
      versionCode: (m["versionCode"] as num?)?.toInt(),
    );
  }

  Future<ApkInfo> apkInfo(String path) async {
    final m = Map<String, dynamic>.from(await _ch.invokeMethod("getApkInfo", {"path": path}));
    return ApkInfo(
      valid: m["valid"] == true,
      packageName: m["packageName"] as String?,
      versionName: m["versionName"] as String?,
      minSdk: (m["minSdk"] as num?)?.toInt(),
    );
  }

  Future<bool> launchMinecraft() async => await _ch.invokeMethod("launchMinecraft") == true;
  Future<void> openStore() => _ch.invokeMethod("openStore");
  Future<void> openMinecraftSettings() => _ch.invokeMethod("openAppSettings");
  Future<void> uninstallMinecraft() => _ch.invokeMethod("uninstallMinecraft");
  Future<bool> canInstallApks() async => await _ch.invokeMethod("canInstallApks") == true;
  Future<void> openInstallPermission() => _ch.invokeMethod("openInstallPermission");
  Future<void> installApk(String path) => _ch.invokeMethod("installApk", {"path": path});
  Future<void> openWithMinecraft(String path) =>
      _ch.invokeMethod("openWithMinecraft", {"path": path});
}
