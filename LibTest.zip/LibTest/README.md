# LibTest
Test app for MinecraftLibraryCache. Push to GitHub, open Actions > Build APK > Artifacts > LibTest-apk.
