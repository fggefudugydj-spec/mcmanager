package com.example.launcher

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val out = TextView(this).apply { textSize = 14f; setTextIsSelectable(true) }
        val btn = Button(this).apply { text = "Test library cache" }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
            addView(btn)
            addView(ScrollView(this@MainActivity).apply { addView(out) })
        }
        setContentView(root)

        btn.setOnClickListener {
            val apks = MinecraftLibraryCache.installedApkPaths(this)
            val sb = StringBuilder("APKs found: ${apks.size}\n")
            apks.forEach { sb.append(" - ${it.path}\n") }
            when (val r = MinecraftLibraryCache.prepare(this, "test", apks)) {
                is MinecraftLibraryCache.Result.Ok ->
                    sb.append("\nOK (${r.abi})\n${r.mainLib.absolutePath}\n")
                is MinecraftLibraryCache.Result.Fail -> {
                    sb.append("\nFAILED: ${r.reason}\n")
                    r.details.forEach { sb.append(" * $it\n") }
                }
            }
            out.text = sb.toString()
        }
    }
}
