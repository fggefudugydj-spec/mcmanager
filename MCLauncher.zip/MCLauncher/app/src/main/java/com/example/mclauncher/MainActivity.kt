package com.example.mclauncher

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.AssetManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import dalvik.system.DexClassLoader
import java.io.File
import java.util.zip.ZipFile
import kotlin.concurrent.thread

const val MC_PKG = "com.mojang.minecraftpe"
const val MC_MAIN = "com.mojang.minecraftpe.MainActivity"

/** المرحلة 1: تطبيق فحص فقط. لا يشغّل اللعبة ولا يعدّل عليها. */
class MainActivity : Activity() {
    private lateinit var log: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val reqApk = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 72, 24, 24)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { f() }
        }
        root.addView(btn("1) فحص الجهاز وماين كرافت المثبتة") { thread { probeInstalled() } })
        root.addView(btn("2) فحص ملف APK من جهازي") { pick() })
        root.addView(btn("3) اختبار صلاحيات الحقن") { thread { probeReflection() } })
        root.addView(btn("نسخ التقرير") { copyLog() })
        log = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            textDirection = View.TEXT_DIRECTION_LTR
        }
        root.addView(
            ScrollView(this).apply { addView(log) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)
        say("جاهز. اضغط الأزرار بالترتيب وصوّر لي التقرير.")
    }

    private fun say(s: String) { ui.post { log.append(s + "\n") } }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("report", log.text))
        Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show()
    }

    // ---------- 1) الجهاز وماين كرافت المثبتة ----------

    private fun probeInstalled() {
        say("\n== الجهاز ==")
        say("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        say("ABIs: ${Build.SUPPORTED_ABIS.joinToString()}")
        say("الجهاز: ${Build.MANUFACTURER} ${Build.MODEL}")
        try {
            val ai = packageManager.getApplicationInfo(MC_PKG, 0)
            val pi = packageManager.getPackageInfo(MC_PKG, 0)
            say("\n== ماين كرافت المثبتة ==")
            say("version=${pi.versionName}")
            say("targetSdk=${ai.targetSdkVersion}")
            say("sourceDir=${ai.sourceDir}")
            val splits = ai.splitSourceDirs
            say("splits=${if (splits == null || splits.isEmpty()) "لا يوجد" else splits.joinToString()}")
            say("nativeLibDir=${ai.nativeLibraryDir}")
            inspectApk(ai.sourceDir, ai.nativeLibraryDir)
        } catch (e: Exception) {
            say("ماين كرافت غير مثبتة: ${e.message}")
        }
    }

    // ---------- 2) ملف APK من الجهاز ----------

    private fun pick() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),
            reqApk
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (requestCode != reqApk || resultCode != RESULT_OK) return
        thread {
            try {
                say("\n== فحص ملف من الجهاز ==")
                say("جارٍ نسخ الملف (قد يأخذ دقايق)...")
                val out = File(filesDir, "probe.apk")
                out.delete()
                contentResolver.openInputStream(uri)!!.use { i ->
                    out.outputStream().use { o -> i.copyTo(o, 1 shl 20) }
                }
                out.setReadOnly() // أندرويد 14 يمنع تحميل كود من ملف قابل للكتابة
                say("تم النسخ")
                inspectApk(out.path, null)
            } catch (t: Throwable) {
                say("خطأ: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    // ---------- فحص ملف APK ----------

    private fun inspectApk(path: String, libDir: String?) {
        say("حجم الملف: ${File(path).length() / 1_000_000} MB")
        val pi = packageManager.getPackageArchiveInfo(path, PackageManager.GET_ACTIVITIES)
        if (pi == null) {
            say("تعذّر قراءته كملف APK")
        } else {
            say("package=${pi.packageName}  version=${pi.versionName}")
            pi.activities?.forEach { say("activity: ${it.name}") }
        }
        try {
            ZipFile(path).use { z ->
                val names = z.entries().asSequence().map { it.name }.toList()
                val libs = names.filter { it.startsWith("lib/") && it.endsWith(".so") }
                say("dex: ${names.count { it.endsWith(".dex") && !it.contains("/") }} ملف")
                say("مكتبات .so: ${libs.size}")
                libs.take(25).forEach { say("  $it") }
                say("assets: ${names.count { it.startsWith("assets/") }} ملف")
                say("resources.arsc: ${if ("resources.arsc" in names) "موجود" else "غير موجود"}")
            }
        } catch (t: Throwable) {
            say("تعذّر فتح الملف كـ zip: ${t.message}")
        }
        try {
            val opt = File(cacheDir, "dexopt").apply { mkdirs() }
            val cl = DexClassLoader(path, opt.path, libDir, classLoader)
            var c: Class<*>? = cl.loadClass(MC_MAIN)
            say("تحميل $MC_MAIN ✓")
            var depth = 0
            while (c != null && depth < 8) {
                say("  ← ${c.name}")
                c = c.superclass
                depth++
            }
        } catch (t: Throwable) {
            say("فشل تحميل MainActivity: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    // ---------- 3) اختبار صلاحيات الحقن ----------

    private fun probeReflection() {
        say("\n== اختبار الحقن (Hidden API) ==")
        fun test(name: String, f: () -> Any?) {
            try {
                say("✓ $name ${f() ?: ""}")
            } catch (t: Throwable) {
                say("✗ $name → ${t.javaClass.simpleName}: ${t.message}")
            }
        }
        var pathList: Any? = null
        test("BaseDexClassLoader.pathList") {
            val f = Class.forName("dalvik.system.BaseDexClassLoader").getDeclaredField("pathList")
            f.isAccessible = true
            pathList = f.get(classLoader)
            pathList?.javaClass?.name
        }
        test("DexPathList.dexElements") {
            val f = pathList!!.javaClass.getDeclaredField("dexElements")
            f.isAccessible = true
            (f.get(pathList) as Array<*>).size
        }
        test("DexPathList.addNativePath") {
            pathList!!.javaClass.getDeclaredMethod("addNativePath", Collection::class.java).name
        }
        test("BaseDexClassLoader.addDexPath") {
            Class.forName("dalvik.system.BaseDexClassLoader")
                .getDeclaredMethod("addDexPath", String::class.java).name
        }
        test("AssetManager.addAssetPath") {
            AssetManager::class.java.getDeclaredMethod("addAssetPath", String::class.java).name
        }
        test("ActivityThread.currentActivityThread") {
            Class.forName("android.app.ActivityThread").getDeclaredMethod("currentActivityThread").name
        }
        test("LoadedApk.mClassLoader") {
            Class.forName("android.app.LoadedApk").getDeclaredField("mClassLoader").name
        }
        say("انتهى الاختبار")
    }
}
