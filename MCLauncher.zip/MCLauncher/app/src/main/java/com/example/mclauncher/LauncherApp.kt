package com.example.mclauncher

import android.app.Activity
import android.app.Application
import android.app.Application.ActivityLifecycleCallbacks
import android.content.Context
import android.content.res.AssetManager
import android.os.Bundle
import android.os.Looper
import android.util.Log
import dalvik.system.DexClassLoader
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val MC_PKG = "com.mojang.minecraftpe"
const val MC_MAIN = "com.mojang.minecraftpe.MainActivity"

object GameLog {
    var file: File? = null
    fun w(s: String) {
        try {
            val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            file?.appendText("$t $s\n")
        } catch (_: Throwable) {
        }
    }
}

object GameLoader {
    var dir: String? = null
    private var loader: ClassLoader? = null

    fun get(parent: ClassLoader): ClassLoader {
        loader?.let { return it }
        val d = dir ?: error("لم يُحدد إصدار")
        GameLog.w("إنشاء DexClassLoader من $d")
        val l = DexClassLoader(File(d, "base.apk").path, null, File(d, "lib").path, parent)
        loader = l
        return l
    }
}

class LauncherApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        // نشتغل فقط داخل عملية اللعبة
        if (Application.getProcessName()?.endsWith(":game") != true) return

        GameLog.file = File(base.filesDir, "launch.log")
        try {
            val d = File(base.filesDir, "selected.txt").readText().trim()
            GameLoader.dir = d
            val apk = File(d, "base.apk").path
            // نضيف ملف اللعبة كمصدر للأصول (assets) لكل نشاط جديد
            val ai = applicationInfo
            ai.sharedLibraryFiles = (ai.sharedLibraryFiles ?: emptyArray()) + apk
            GameLog.w("Application: أُضيف مصدر الأصول")
            injectNativePath(File(d, "lib").path)
        } catch (t: Throwable) {
            GameLog.w("Application فشل: $t")
        }

        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, e ->
            try {
                File(base.filesDir, "crash.txt").writeText(Log.getStackTraceString(e))
            } catch (_: Throwable) {
            }
            prev?.uncaughtException(th, e)
        }
    }


    override fun onCreate() {
        super.onCreate()
        if (Application.getProcessName()?.endsWith(":game") != true) return
        GameLog.w("Application.onCreate")
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityPreCreated(a: Activity, s: Bundle?) { prepareAssets(a) }
            override fun onActivityCreated(a: Activity, s: Bundle?) { GameLog.w("onCreate انتهى: ${a.javaClass.name}") }
            override fun onActivityStarted(a: Activity) { GameLog.w("onStart") }
            override fun onActivityResumed(a: Activity) { GameLog.w("onResume") }
            override fun onActivityPaused(a: Activity) { GameLog.w("onPause") }
            override fun onActivityStopped(a: Activity) { GameLog.w("onStop") }
            override fun onActivitySaveInstanceState(a: Activity, o: Bundle) {}
            override fun onActivityDestroyed(a: Activity) { GameLog.w("onDestroy") }
        })
        startWatchdog()
    }

    private fun prepareAssets(a: Activity) {
        try {
            val before = a.assets.list("")?.size ?: -1
            GameLog.w("قبل onCreate: pkg=${a.packageName} عدد عناصر assets=$before")
            if (before < 3) {
                val apk = File(GameLoader.dir, "base.apk").path
                val m = AssetManager::class.java.getDeclaredMethod("addAssetPath", String::class.java)
                GameLog.w("addAssetPath → ${m.invoke(a.assets, apk)}")
            }
            val after = a.assets.list("") ?: emptyArray()
            GameLog.w("assets بعد: ${after.size} → ${after.take(8).joinToString()}")
        } catch (t: Throwable) {
            GameLog.w("prepareAssets فشل: $t")
        }
    }

    private fun startWatchdog() {
        Thread {
            var sec = 0.0
            repeat(6) { i ->
                try { Thread.sleep(2500) } catch (_: Throwable) {}
                sec += 2.5
                val maps = try { File("/proc/self/maps").readText() } catch (_: Throwable) { "" }
                val line = maps.lineSequence().firstOrNull { it.contains("libminecraftpe") }
                GameLog.w("مراقب +${sec}s: libminecraftpe=${line?.substringAfterLast(' ') ?: "غير محمّلة"}")
                if (i == 5) {
                    val st = Looper.getMainLooper().thread.stackTrace.take(10).joinToString(" | ")
                    GameLog.w("الخيط الرئيسي: $st")
                }
            }
        }.start()
    }

    private fun injectNativePath(lib: String) {
        try {
            val f = Class.forName("dalvik.system.BaseDexClassLoader").getDeclaredField("pathList")
            f.isAccessible = true
            val pl = f.get(classLoader)!!
            val m = pl.javaClass.getDeclaredMethod("addNativePath", Collection::class.java)
            m.isAccessible = true
            m.invoke(pl, listOf(lib))
            GameLog.w("أُضيف مسار المكتبات لـ classloader التطبيق")
        } catch (t: Throwable) {
            GameLog.w("addNativePath غير متاح: ${t.javaClass.simpleName}")
        }
    }
}
