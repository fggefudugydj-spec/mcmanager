package com.example.mclauncher

import android.app.Activity
import android.app.AppComponentFactory
import android.content.Intent

/** يُنشئ نشاط ماين كرافت من ملف APK المختار بدل البحث عنه داخل تطبيقنا. */
class GameFactory : AppComponentFactory() {
    override fun instantiateActivity(cl: ClassLoader, className: String, intent: Intent?): Activity {
        if (className == MC_MAIN && GameLoader.dir != null) {
            GameLog.w("Factory: تحميل $className")
            val c = GameLoader.get(cl).loadClass(className)
            GameLog.w("Factory: تحمّل الكلاس، الأب=${c.superclass?.name}")
            val ctor = c.getDeclaredConstructor()
            ctor.isAccessible = true
            val a = ctor.newInstance() as Activity
            GameLog.w("Factory: تم إنشاء النشاط")
            return a
        }
        return super.instantiateActivity(cl, className, intent)
    }
}
