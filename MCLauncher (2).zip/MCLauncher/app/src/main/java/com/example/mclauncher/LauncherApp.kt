package com.example.mclauncher

import android.app.Application
import android.content.Context
import android.util.Log
import dalvik.system.DexClassLoader
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val MC_PKG = "com.mojang.minecraftpe"
const val MC_MAIN = "com.mojang.minecraftpe.MainActivity"

object GameLog {
    var file: File? = null
    fun w(s: String) {
        try {
            val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            file?.appendText("$t $s\n")
        } catch (_: Throwable) {
        }
    }
}

object GameLoader {
    var dir: String? = null
    private var loader: ClassLoader? = null

    fun get(parent: ClassLoader): ClassLoader {
        loader?.let { return it }
        val d = dir ?: error("لم يُحدد إصدار")
        GameLog.w("إنشاء DexClassLoader من $d")
        val l = DexClassLoader(File(d, "base.apk").path, null, File(d, "lib").path, parent)
        loader = l
        return l
    }
}

class LauncherApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        // نشتغل فقط داخل عملية اللعبة
        if (Application.getProcessName()?.endsWith(":game") != true) return

        GameLog.file = File(base.filesDir, "launch.log")
        try {
            val d = File(base.filesDir, "selected.txt").readText().trim()
            GameLoader.dir = d
            val apk = File(d, "base.apk").path
            // نضيف ملف اللعبة كمصدر للأصول (assets) لكل نشاط جديد
            val ai = applicationInfo
            ai.sharedLibraryFiles = (ai.sharedLibraryFiles ?: emptyArray()) + apk
            GameLog.w("Application: أُضيف مصدر الأصول")
            injectNativePath(File(d, "lib").path)
        } catch (t: Throwable) {
            GameLog.w("Application فشل: $t")
        }

        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, e ->
            try {
                File(base.filesDir, "crash.txt").writeText(Log.getStackTraceString(e))
            } catch (_: Throwable) {
            }
            prev?.uncaughtException(th, e)
        }
    }

    private fun injectNativePath(lib: String) {
        try {
            val f = Class.forName("dalvik.system.BaseDexClassLoader").getDeclaredField("pathList")
            f.isAccessible = true
            val pl = f.get(classLoader)!!
            val m = pl.javaClass.getDeclaredMethod("addNativePath", Collection::class.java)
            m.isAccessible = true
            m.invoke(pl, listOf(lib))
            GameLog.w("أُضيف مسار المكتبات لـ classloader التطبيق")
        } catch (t: Throwable) {
            GameLog.w("addNativePath غير متاح: ${t.javaClass.simpleName}")
        }
    }
}
