package com.example.mclauncher

import android.app.Activity
import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.zip.ZipFile
import kotlin.concurrent.thread

class LauncherActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val reqApk = 1
    private lateinit var list: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 80, 32, 32)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply { text = "مشغّل ماين كرافت"; textSize = 22f })
        root.addView(button("إضافة إصدار (ملف APK)") { pick() })
        status = TextView(this).apply { setPadding(0, 16, 0, 16) }
        root.addView(status)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(
            ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(button("السجل وآخر خطأ") { showLog() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(button("الإصدارات") { refresh() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(bar)
        setContentView(root)
        refresh()
    }

    private fun button(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { f() }
    }

    private fun say(s: String) { ui.post { status.text = s } }

    private fun versions(): List<File> =
        File(filesDir, "versions").listFiles()
            ?.filter { File(it, "base.apk").exists() && File(it, "meta.txt").exists() }
            ?.sortedBy { it.name } ?: emptyList()

    private fun refresh() {
        list.removeAllViews()
        val vs = versions()
        if (vs.isEmpty()) {
            list.addView(TextView(this).apply { text = "لا توجد إصدارات. أضف ملف APK لماين كرافت تملكه." })
        }
        for (d in vs) {
            val name = File(d, "meta.txt").readText().trim()
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(
                TextView(this).apply { text = name; textSize = 17f },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(button("تشغيل") { launch(d) })
            row.addView(button("حذف") { d.deleteRecursively(); refresh() })
            list.addView(row)
        }
    }

    // ---------- إضافة إصدار ----------

    private fun pick() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),
            reqApk
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (requestCode == reqApk && resultCode == RESULT_OK) importApk(uri)
    }

    private fun importApk(uri: Uri) = thread {
        try {
            say("جارٍ النسخ... الملف كبير، انتظر دقايق")
            val tmp = File(filesDir, "versions/tmp_${System.currentTimeMillis()}").apply { mkdirs() }
            val apk = File(tmp, "base.apk")
            contentResolver.openInputStream(uri)!!.use { i ->
                apk.outputStream().use { o -> i.copyTo(o, 1 shl 20) }
            }
            val pi = packageManager.getPackageArchiveInfo(apk.path, 0)
            if (pi == null || pi.packageName != MC_PKG) {
                tmp.deleteRecursively()
                say("هذا الملف ليس APK لماين كرافت")
                return@thread
            }
            val name = pi.versionName ?: "unknown"
            val dest = File(filesDir, "versions/v_$name")
            if (dest.exists()) {
                tmp.deleteRecursively()
                say("الإصدار $name موجود مسبقًا")
                return@thread
            }
            say("جارٍ استخراج المكتبات...")
            extractLibs(apk, File(tmp, "lib"))
            apk.setReadOnly()
            File(tmp, "meta.txt").writeText(name)
            tmp.renameTo(dest)
            say("تمت إضافة $name ✓")
            ui.post { refresh() }
        } catch (t: Throwable) {
            say("خطأ: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun extractLibs(apk: File, out: File) {
        out.mkdirs()
        var n = 0
        ZipFile(apk).use { z ->
            for (e in z.entries()) {
                if (e.name.startsWith("lib/arm64-v8a/") && e.name.endsWith(".so")) {
                    File(out, e.name.substringAfterLast('/')).outputStream().use { o ->
                        z.getInputStream(e).use { it.copyTo(o) }
                    }
                    n++
                }
            }
        }
        if (n == 0) error("لا توجد مكتبات arm64 داخل الملف")
    }

    // ---------- التشغيل ----------

    private fun launch(dir: File) {
        File(filesDir, "selected.txt").writeText(dir.path)
        File(filesDir, "launch.log").delete()
        File(filesDir, "crash.txt").delete()
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        am.runningAppProcesses?.filter { it.processName.endsWith(":game") }
            ?.forEach { android.os.Process.killProcess(it.pid) }
        say("جارٍ التشغيل...")
        ui.postDelayed({
            try {
                startActivity(Intent().setClassName(this, MC_MAIN))
            } catch (t: Throwable) {
                say("فشل التشغيل: ${t.message}")
            }
        }, 600)
    }

    private fun showLog() {
        fun read(n: String) = File(filesDir, n).takeIf { it.exists() }?.readText() ?: "(لا يوجد)"
        val text = "== السجل ==\n${read("launch.log")}\n== آخر خطأ ==\n${read("crash.txt")}"
        list.removeAllViews()
        list.addView(TextView(this).apply {
            this.text = text
            textSize = 11f
            setTextIsSelectable(true)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            textDirection = View.TEXT_DIRECTION_LTR
        })
        list.addView(button("نسخ") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", text))
            Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show()
        })
    }
}
