package org.levifix;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.util.Log;

import java.io.File;

/**
 * High-level helper that tries to automatically recover from
 * "libminecraftpe.so not found in the Minecraft library cache".
 */
public final class LibraryRepairHelper {

    private static final String TAG = "LeviFix";
    private static final String MINECRAFT_PACKAGE = "com.mojang.minecraftpe";

    private LibraryRepairHelper() {}

    public static String tryRepair(Context context, File cacheDir) {
        return tryRepair(context, cacheDir, null, null);
    }

    public static String tryRepair(Context context, File cacheDir, String apkPath) {
        return tryRepair(context, cacheDir, apkPath, null);
    }

    /**
     * Full repair attempt with optional APK path and progress listener.
     */
    public static String tryRepair(Context context, File cacheDir, String apkPath,
                                   NativeBridge.ProgressListener listener) {
        Log.i(TAG, "Starting library repair...");

        if (listener != null) {
            NativeBridge.setProgressListener(listener);
        }

        try {
            // 1. Search existing cache
            String existing = NativeBridge.findMinecraftPE(cacheDir.getAbsolutePath());
            if (existing != null) {
                Log.i(TAG, "Library already present: " + existing);
                if (listener != null) listener.onProgress(100, "Already available");
                return existing;
            }

            if (!cacheDir.exists() && !cacheDir.mkdirs()) {
                Log.e(TAG, "Cannot create cache directory");
                return null;
            }

            // 2. Copy from official Minecraft nativeLibraryDir
            String nativeLibDir = getMinecraftNativeLibDir(context);
            if (nativeLibDir != null) {
                Log.i(TAG, "Attempting copy from nativeLibraryDir: " + nativeLibDir);

                String result = NativeBridge.rebuildCacheFromNativeDir(
                        cacheDir.getAbsolutePath(),
                        nativeLibDir
                );

                if (result != null && result.startsWith("/")) {
                    Log.i(TAG, "Repair successful from nativeLibraryDir: " + result);
                    return result;
                } else {
                    Log.w(TAG, "nativeLibraryDir copy failed: " + result);
                }
            } else {
                Log.w(TAG, "Could not locate Minecraft nativeLibraryDir");
            }

            // 3. Extract from APK (all .so files)
            if (apkPath != null && !apkPath.isEmpty()) {
                Log.i(TAG, "Attempting extraction from APK: " + apkPath);

                String result = NativeBridge.extractFromApk(
                        cacheDir.getAbsolutePath(),
                        apkPath
                );

                if (result != null && result.startsWith("/")) {
                    Log.i(TAG, "Repair successful from APK: " + result);
                    return result;
                } else {
                    Log.e(TAG, "APK extraction failed: " + result);
                }
            }

            Log.e(TAG, "All repair methods failed");
            return null;
        } finally {
            // Clear listener to avoid leaks
            NativeBridge.setProgressListener(null);
        }
    }

    private static String getMinecraftNativeLibDir(Context context) {
        try {
            ApplicationInfo info = context.getPackageManager()
                    .getApplicationInfo(MINECRAFT_PACKAGE, 0);
            return info.nativeLibraryDir;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "Minecraft package not found", e);
            return null;
        }
    }
}
