package org.levifix.ui;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.levifix.LibraryRepairHelper;
import org.levifix.NativeBridge;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * مثال كامل لكيفية استخدام نظام إصلاح المكتبات.
 */
public class RepairActivity extends Activity {

    private static final String TAG = "LeviFix.UI";

    private ProgressBar progressBar;
    private TextView statusText;
    private TextView resultText;
    private Button repairButton;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    // ضع مسار الـ APK هنا إذا تبيه (أو خله null)
    private String optionalApkPath = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(org.levifix.R.layout.activity_repair);

        progressBar = findViewById(org.levifix.R.id.progressBar);
        statusText = findViewById(org.levifix.R.id.statusText);
        resultText = findViewById(org.levifix.R.id.resultText);
        repairButton = findViewById(org.levifix.R.id.repairButton);

        progressBar.setMax(100);
        progressBar.setProgress(0);

        repairButton.setOnClickListener(v -> startRepair());
    }

    private void startRepair() {
        repairButton.setEnabled(false);
        progressBar.setProgress(0);
        statusText.setText("جاري التحضير...");
        resultText.setText("");

        File cacheDir = new File(getFilesDir(), "minecraft_lib_cache");

        executor.execute(() -> {
            String libPath = LibraryRepairHelper.tryRepair(
                    this,
                    cacheDir,
                    optionalApkPath,
                    (percent, status) -> mainHandler.post(() -> {
                        progressBar.setProgress(percent);
                        statusText.setText(status);
                    })
            );

            mainHandler.post(() -> {
                repairButton.setEnabled(true);

                if (libPath != null) {
                    progressBar.setProgress(100);
                    statusText.setText("تم الإصلاح بنجاح");
                    resultText.setText("المسار:\n" + libPath);
                    Toast.makeText(this, "تم العثور على libminecraftpe.so", Toast.LENGTH_LONG).show();
                    Log.i(TAG, "Repair success: " + libPath);
                } else {
                    statusText.setText("فشل الإصلاح");
                    resultText.setText("تأكد أن ماينكرافت مثبتة وفتحتها مرة واحدة على الأقل،\nأو مرّر مسار APK صحيح.");
                    Toast.makeText(this, "فشل إصلاح المكتبة", Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Repair failed");
                }
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
        NativeBridge.setProgressListener(null);
    }
}
