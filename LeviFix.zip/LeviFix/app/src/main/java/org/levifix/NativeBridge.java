package org.levifix;

/**
 * Native bridge to the C++ library finder & extractor.
 */
public final class NativeBridge {

    static {
        System.loadLibrary("levifix");
    }

    private NativeBridge() {}

    /** Interface for receiving progress updates from native code */
    public interface ProgressListener {
        void onProgress(int percent, String status);
    }

    /**
     * Register a progress listener. Pass null to clear.
     * Must be called from the Java side before long operations.
     */
    public static native void setProgressListener(ProgressListener listener);

    public static native String findMinecraftPE(String cacheDir);

    public static native boolean isValidLibrary(String path);

    public static native String rebuildCacheFromNativeDir(String outputDir, String nativeLibDir);

    public static native String getDeviceAbi();

    /**
     * Extract ALL .so files from the given APK (lib/<abi>/) into outputDir.
     * Progress is reported via the registered ProgressListener.
     */
    public static native String extractFromApk(String outputDir, String apkPath);
}
