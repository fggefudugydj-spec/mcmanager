#include "library_finder.h"

#include <sys/stat.h>
#include <fstream>
#include <android/log.h>
#include <unistd.h>
#include <dirent.h>

#define LOG_TAG "LeviFix"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace levifix {

LibraryFinder::LibraryFinder(std::string cache_dir, std::string minecraft_package)
    : cache_dir_(std::move(cache_dir)),
      minecraft_package_(std::move(minecraft_package)) {
}

std::string LibraryFinder::getDeviceAbi() {
#if defined(__aarch64__)
    return "arm64-v8a";
#elif defined(__arm__)
    return "armeabi-v7a";
#elif defined(__x86_64__)
    return "x86_64";
#elif defined(__i386__)
    return "x86";
#else
    return "unknown";
#endif
}

bool LibraryFinder::isValidLibrary(const std::string& path) {
    struct stat st {};
    if (stat(path.c_str(), &st) != 0) {
        return false;
    }

    // libminecraftpe.so عادة أكبر من 5 ميجا
    if (st.st_size < 5 * 1024 * 1024) {
        LOGE("Library too small: %s (%ld bytes)", path.c_str(), st.st_size);
        return false;
    }

    // تحقق بسيط من ELF magic
    std::ifstream file(path, std::ios::binary);
    if (!file) return false;

    char magic[4] = {};
    file.read(magic, 4);
    if (magic[0] != 0x7F || magic[1] != 'E' || magic[2] != 'L' || magic[3] != 'F') {
        LOGE("Not a valid ELF: %s", path.c_str());
        return false;
    }

    return true;
}

std::optional<LibraryInfo> LibraryFinder::checkPath(const std::string& path, const std::string& source) const {
    if (!isValidLibrary(path)) {
        return std::nullopt;
    }

    struct stat st {};
    stat(path.c_str(), &st);

    LibraryInfo info;
    info.path = path;
    info.size = static_cast<size_t>(st.st_size);
    info.is_valid = true;
    info.source = source;

    LOGI("Found valid library: %s (source=%s, size=%zu)", path.c_str(), source.c_str(), info.size);
    return info;
}

std::vector<std::string> LibraryFinder::buildSearchPaths() const {
    std::vector<std::string> paths;
    const std::string abi = getDeviceAbi();

    // 1. كاش اللونشر (الأولوية الأعلى)
    paths.push_back(cache_dir_ + "/libminecraftpe.so");
    paths.push_back(cache_dir_ + "/" + abi + "/libminecraftpe.so");

    // 2. nativeLibraryDir لماينكرافت الرسمية (بعد ما تفتح اللعبة مرة)
    // مسار تقريبي - في التطبيق الحقيقي نجيبو من PackageManager
    paths.push_back("/data/app/" + minecraft_package_ + "-*/lib/" + abi + "/libminecraftpe.so");

    // 3. داخل مجلدات شائعة
    paths.push_back("/data/data/" + minecraft_package_ + "/lib/libminecraftpe.so");

    return paths;
}

std::optional<LibraryInfo> LibraryFinder::findMinecraftPE() {
    auto candidates = findAllCandidates();
    if (!candidates.empty()) {
        return candidates.front();
    }
    LOGE("libminecraftpe.so not found in any known location");
    return std::nullopt;
}

std::vector<LibraryInfo> LibraryFinder::findAllCandidates() {
    std::vector<LibraryInfo> results;

    // أولاً: البحث في الكاش المباشر
    auto direct = checkPath(cache_dir_ + "/libminecraftpe.so", "cache");
    if (direct) results.push_back(*direct);

    auto abi_path = checkPath(cache_dir_ + "/" + getDeviceAbi() + "/libminecraftpe.so", "cache-abi");
    if (abi_path) results.push_back(*abi_path);

    // ثانياً: محاولة البحث في مسارات النظام (إذا كان عندنا صلاحية)
    // ملاحظة: في التطبيق الحقيقي نستخدم PackageManager + nativeLibraryDir

    return results;
}

} // namespace levifix
