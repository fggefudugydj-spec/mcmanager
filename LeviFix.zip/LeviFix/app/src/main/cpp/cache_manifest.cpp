#include "cache_manifest.h"

#include <fstream>
#include <sstream>
#include <sys/stat.h>
#include <android/log.h>
#include <cstring>

#define LOG_TAG "LeviFix"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace levifix {

namespace {

std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

} // namespace

std::string CacheManifest::serialize() const {
    std::ostringstream oss;
    oss << "version=" << version << "\n";
    oss << "abi=" << abi << "\n";
    oss << "source=" << source << "\n";
    oss << "source_id=" << source_id << "\n";
    oss << "file_count=" << files.size() << "\n";
    oss << "---\n";

    for (const auto& f : files) {
        oss << f.name << "|" << f.size << "|" << f.crc32 << "\n";
    }
    return oss.str();
}

std::optional<CacheManifest> CacheManifest::deserialize(const std::string& content) {
    CacheManifest m;
    std::istringstream iss(content);
    std::string line;
    bool inFiles = false;

    while (std::getline(iss, line)) {
        line = trim(line);
        if (line.empty()) continue;

        if (line == "---") {
            inFiles = true;
            continue;
        }

        if (!inFiles) {
            auto pos = line.find('=');
            if (pos == std::string::npos) continue;
            std::string key = line.substr(0, pos);
            std::string value = line.substr(pos + 1);

            if (key == "version") m.version = std::stoi(value);
            else if (key == "abi") m.abi = value;
            else if (key == "source") m.source = value;
            else if (key == "source_id") m.source_id = value;
            // file_count نتجاهله، نعد من القائمة
        } else {
            // name|size|crc32
            size_t p1 = line.find('|');
            if (p1 == std::string::npos) continue;
            size_t p2 = line.find('|', p1 + 1);

            ManifestEntry e;
            e.name = line.substr(0, p1);
            try {
                if (p2 != std::string::npos) {
                    e.size = static_cast<size_t>(std::stoull(line.substr(p1 + 1, p2 - p1 - 1)));
                    e.crc32 = static_cast<uint32_t>(std::stoul(line.substr(p2 + 1)));
                } else {
                    e.size = static_cast<size_t>(std::stoull(line.substr(p1 + 1)));
                }
            } catch (...) {
                continue;
            }
            m.files.push_back(e);
        }
    }

    if (m.abi.empty() || m.files.empty()) {
        return std::nullopt;
    }
    return m;
}

bool CacheManifest::save(const std::string& path) const {
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) {
        LOGE("Cannot write manifest: %s", path.c_str());
        return false;
    }
    out << serialize();
    return out.good();
}

std::optional<CacheManifest> CacheManifest::load(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return std::nullopt;

    std::ostringstream oss;
    oss << in.rdbuf();
    return deserialize(oss.str());
}

bool CacheManifest::matchesDirectory(const std::string& dir) const {
    for (const auto& f : files) {
        std::string full = dir + "/" + f.name;
        struct stat st {};
        if (stat(full.c_str(), &st) != 0) {
            LOGI("Manifest miss: file not found %s", f.name.c_str());
            return false;
        }
        if (static_cast<size_t>(st.st_size) != f.size) {
            LOGI("Manifest miss: size mismatch %s (expected %zu, got %ld)",
                 f.name.c_str(), f.size, st.st_size);
            return false;
        }
    }
    return true;
}

} // namespace levifix
