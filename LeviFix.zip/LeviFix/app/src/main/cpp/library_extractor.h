#pragma once

#include <string>
#include <vector>
#include <functional>
#include "cache_manifest.h"

namespace levifix {

struct ExtractionResult {
    bool success = false;
    std::string message;
    std::string extracted_path;
    std::vector<std::string> extracted_files;
    bool used_cache = false;   // true إذا استخدمنا الكاش الموجود بدون إعادة استخراج
};

class LibraryExtractor {
public:
    using ProgressCallback = std::function<void(int percent, const std::string& status)>;

    explicit LibraryExtractor(std::string output_dir);

    // استخراج المكتبات من مسار APK
    ExtractionResult extractFromApk(const std::string& apk_path, ProgressCallback cb = nullptr);

    // استخراج من مجلد nativeLibraryDir مباشرة (أسرع)
    ExtractionResult copyFromNativeDir(const std::string& native_lib_dir, ProgressCallback cb = nullptr);

    // إعادة بناء الكاش بالكامل
    ExtractionResult rebuildCache(const std::string& source_path, bool is_apk, ProgressCallback cb = nullptr);

    // هل الكاش الحالي صالح حسب الـ Manifest؟
    bool isCacheValid(const std::string& expected_source = "", const std::string& expected_source_id = "") const;

    // مسار ملف الـ Manifest
    std::string manifestPath() const;

private:
    std::string output_dir_;
    std::string abi_;

    bool ensureOutputDir();
    bool copyFile(const std::string& src, const std::string& dst);

    // بناء Manifest من الملفات الموجودة حاليًا في المجلد
    CacheManifest buildManifestFromDir(const std::string& source, const std::string& source_id) const;

    // كتابة الـ Manifest بعد نجاح العملية
    bool writeManifest(const CacheManifest& manifest) const;
};

} // namespace levifix
