#pragma once

#include <string>
#include <vector>
#include <optional>

namespace levifix {

struct ManifestEntry {
    std::string name;       // اسم الملف (مثل libminecraftpe.so)
    size_t size = 0;        // حجم الملف بالبايت
    uint32_t crc32 = 0;     // اختياري للمستقبل
};

struct CacheManifest {
    int version = 1;                        // إصدار تنسيق الـ Manifest
    std::string abi;                        // arm64-v8a ...
    std::string source;                     // "native" أو "apk" أو مسار المصدر
    std::string source_id;                  // يمكن يكون hash أو lastModified
    std::vector<ManifestEntry> files;       // قائمة الملفات الموجودة في الكاش

    // تحويل من/إلى نص
    std::string serialize() const;
    static std::optional<CacheManifest> deserialize(const std::string& content);

    // كتابة وقراءة من ملف
    bool save(const std::string& path) const;
    static std::optional<CacheManifest> load(const std::string& path);

    // هل الكاش الحالي يطابق الـ Manifest؟
    bool matchesDirectory(const std::string& dir) const;
};

} // namespace levifix
