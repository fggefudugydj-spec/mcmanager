#include <jni.h>
#include <string>
#include <android/log.h>

#include "library_finder.h"
#include "library_extractor.h"

#define LOG_TAG "LeviFix"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// نحتفظ بمراجع الـ callback عشان نقدر نناديها من C++
static JavaVM* g_vm = nullptr;
static jobject g_progressListener = nullptr;
static jmethodID g_onProgressMethod = nullptr;

extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* /* reserved */) {
    g_vm = vm;
    return JNI_VERSION_1_6;
}

// تسجيل مستمع التقدم من Java
JNIEXPORT void JNICALL
Java_org_levifix_NativeBridge_setProgressListener(JNIEnv* env, jclass /* clazz */, jobject listener) {
    if (g_progressListener) {
        env->DeleteGlobalRef(g_progressListener);
        g_progressListener = nullptr;
        g_onProgressMethod = nullptr;
    }

    if (listener) {
        g_progressListener = env->NewGlobalRef(listener);
        jclass cls = env->GetObjectClass(listener);
        g_onProgressMethod = env->GetMethodID(cls, "onProgress", "(ILjava/lang/String;)V");
        env->DeleteLocalRef(cls);

        if (!g_onProgressMethod) {
            LOGE("onProgress method not found on listener");
            env->DeleteGlobalRef(g_progressListener);
            g_progressListener = nullptr;
        }
    }
}

static void notifyProgress(int percent, const std::string& status) {
    if (!g_vm || !g_progressListener || !g_onProgressMethod) return;

    JNIEnv* env = nullptr;
    bool attached = false;

    if (g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) {
            return;
        }
        attached = true;
    }

    jstring jStatus = env->NewStringUTF(status.c_str());
    env->CallVoidMethod(g_progressListener, g_onProgressMethod, percent, jStatus);
    env->DeleteLocalRef(jStatus);

    if (attached) {
        g_vm->DetachCurrentThread();
    }
}

// البحث عن libminecraftpe.so
JNIEXPORT jstring JNICALL
Java_org_levifix_NativeBridge_findMinecraftPE(JNIEnv* env, jobject /* thiz */, jstring cacheDir) {
    const char* cache = env->GetStringUTFChars(cacheDir, nullptr);
    if (!cache) return nullptr;

    levifix::LibraryFinder finder(cache);
    auto result = finder.findMinecraftPE();

    env->ReleaseStringUTFChars(cacheDir, cache);

    if (result) {
        LOGI("Found library at: %s", result->path.c_str());
        return env->NewStringUTF(result->path.c_str());
    }

    LOGE("Library not found");
    return nullptr;
}

// التحقق من صحة مكتبة
JNIEXPORT jboolean JNICALL
Java_org_levifix_NativeBridge_isValidLibrary(JNIEnv* env, jobject /* thiz */, jstring path) {
    const char* p = env->GetStringUTFChars(path, nullptr);
    if (!p) return JNI_FALSE;

    bool valid = levifix::LibraryFinder::isValidLibrary(p);
    env->ReleaseStringUTFChars(path, p);

    return valid ? JNI_TRUE : JNI_FALSE;
}

// إعادة بناء الكاش من nativeLibraryDir
JNIEXPORT jstring JNICALL
Java_org_levifix_NativeBridge_rebuildCacheFromNativeDir(JNIEnv* env, jobject /* thiz */,
                                                        jstring outputDir, jstring nativeLibDir) {
    const char* out = env->GetStringUTFChars(outputDir, nullptr);
    const char* native = env->GetStringUTFChars(nativeLibDir, nullptr);

    if (!out || !native) {
        if (out) env->ReleaseStringUTFChars(outputDir, out);
        if (native) env->ReleaseStringUTFChars(nativeLibDir, native);
        return env->NewStringUTF("Invalid arguments");
    }

    levifix::LibraryExtractor extractor(out);
    auto result = extractor.copyFromNativeDir(native, [](int percent, const std::string& status) {
        notifyProgress(percent, status);
    });

    env->ReleaseStringUTFChars(outputDir, out);
    env->ReleaseStringUTFChars(nativeLibDir, native);

    if (result.success) {
        return env->NewStringUTF(result.extracted_path.c_str());
    }
    return env->NewStringUTF(result.message.c_str());
}

// الحصول على ABI
JNIEXPORT jstring JNICALL
Java_org_levifix_NativeBridge_getDeviceAbi(JNIEnv* env, jobject /* thiz */) {
    std::string abi = levifix::LibraryFinder::getDeviceAbi();
    return env->NewStringUTF(abi.c_str());
}

// استخراج المكتبات من ملف APK باستخدام minizip
JNIEXPORT jstring JNICALL
Java_org_levifix_NativeBridge_extractFromApk(JNIEnv* env, jobject /* thiz */,
                                             jstring outputDir, jstring apkPath) {
    const char* out = env->GetStringUTFChars(outputDir, nullptr);
    const char* apk = env->GetStringUTFChars(apkPath, nullptr);

    if (!out || !apk) {
        if (out) env->ReleaseStringUTFChars(outputDir, out);
        if (apk) env->ReleaseStringUTFChars(apkPath, apk);
        return env->NewStringUTF("Invalid arguments");
    }

    levifix::LibraryExtractor extractor(out);
    auto result = extractor.extractFromApk(apk, [](int percent, const std::string& status) {
        notifyProgress(percent, status);
    });

    env->ReleaseStringUTFChars(outputDir, out);
    env->ReleaseStringUTFChars(apkPath, apk);

    if (result.success) {
        return env->NewStringUTF(result.extracted_path.c_str());
    }
    return env->NewStringUTF(result.message.c_str());
}

} // extern "C"
