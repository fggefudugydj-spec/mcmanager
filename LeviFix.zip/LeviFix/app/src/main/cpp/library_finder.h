#pragma once

#include <string>
#include <vector>
#include <optional>

namespace levifix {

struct LibraryInfo {
    std::string path;
    size_t size = 0;
    bool is_valid = false;
    std::string source; // "cache", "system", "apk", "fallback"
};

class LibraryFinder {
public:
    explicit LibraryFinder(std::string cache_dir, std::string minecraft_package = "com.mojang.minecraftpe");

    // البحث الرئيسي - يرجع أول مكتبة صالحة
    std::optional<LibraryInfo> findMinecraftPE();

    // بحث شامل مع كل النتائج
    std::vector<LibraryInfo> findAllCandidates();

    // التحقق من صحة الملف
    static bool isValidLibrary(const std::string& path);

    // الحصول على ABI الجهاز
    static std::string getDeviceAbi();

private:
    std::string cache_dir_;
    std::string minecraft_package_;

    std::vector<std::string> buildSearchPaths() const;
    std::optional<LibraryInfo> checkPath(const std::string& path, const std::string& source) const;
};

} // namespace levifix
