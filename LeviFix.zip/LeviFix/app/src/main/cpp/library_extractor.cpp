#include "library_extractor.h"
#include "library_finder.h"

#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <fstream>
#include <android/log.h>
#include <unistd.h>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>

#include "unzip.h"

#define LOG_TAG "LeviFix"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace levifix {

namespace {

bool fileExists(const std::string& path) {
    return access(path.c_str(), F_OK) == 0;
}

bool ensureDir(const std::string& path) {
    struct stat st {};
    if (stat(path.c_str(), &st) == 0) {
        return S_ISDIR(st.st_mode);
    }
    return mkdir(path.c_str(), 0755) == 0;
}

bool endsWith(const std::string& value, const std::string& ending) {
    if (ending.size() > value.size()) return false;
    return std::equal(ending.rbegin(), ending.rend(), value.rbegin());
}

bool extractOneFile(unzFile zip, const std::string& outPath) {
    if (unzOpenCurrentFile(zip) != UNZ_OK) {
        LOGE("unzOpenCurrentFile failed for %s", outPath.c_str());
        return false;
    }

    std::ofstream out(outPath, std::ios::binary);
    if (!out) {
        unzCloseCurrentFile(zip);
        LOGE("Cannot create output file: %s", outPath.c_str());
        return false;
    }

    char buffer[8192];
    int bytes = 0;
    do {
        bytes = unzReadCurrentFile(zip, buffer, sizeof(buffer));
        if (bytes < 0) {
            LOGE("Error reading zip content");
            unzCloseCurrentFile(zip);
            return false;
        }
        if (bytes > 0) {
            out.write(buffer, bytes);
        }
    } while (bytes > 0);

    unzCloseCurrentFile(zip);
    out.close();
    return true;
}

size_t getFileSize(const std::string& path) {
    struct stat st {};
    if (stat(path.c_str(), &st) != 0) return 0;
    return static_cast<size_t>(st.st_size);
}

} // anonymous namespace

LibraryExtractor::LibraryExtractor(std::string output_dir)
    : output_dir_(std::move(output_dir)),
      abi_(LibraryFinder::getDeviceAbi()) {
}

std::string LibraryExtractor::manifestPath() const {
    return output_dir_ + "/.extraction_manifest";
}

bool LibraryExtractor::ensureOutputDir() {
    return ensureDir(output_dir_);
}

bool LibraryExtractor::copyFile(const std::string& src, const std::string& dst) {
    std::ifstream in(src, std::ios::binary);
    if (!in) return false;
    std::ofstream out(dst, std::ios::binary);
    if (!out) return false;
    out << in.rdbuf();
    return out.good();
}

CacheManifest LibraryExtractor::buildManifestFromDir(const std::string& source,
                                                     const std::string& source_id) const {
    CacheManifest m;
    m.version = 1;
    m.abi = abi_;
    m.source = source;
    m.source_id = source_id;

    DIR* dir = opendir(output_dir_.c_str());
    if (!dir) return m;

    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;
        if (name == "." || name == ".." || name == ".extraction_manifest") continue;
        if (!endsWith(name, ".so")) continue;

        std::string full = output_dir_ + "/" + name;
        ManifestEntry e;
        e.name = name;
        e.size = getFileSize(full);
        e.crc32 = 0; // يمكن إضافته لاحقًا
        m.files.push_back(e);
    }
    closedir(dir);
    return m;
}

bool LibraryExtractor::writeManifest(const CacheManifest& manifest) const {
    return manifest.save(manifestPath());
}

bool LibraryExtractor::isCacheValid(const std::string& expected_source,
                                    const std::string& expected_source_id) const {
    auto opt = CacheManifest::load(manifestPath());
    if (!opt) {
        LOGI("No valid manifest found");
        return false;
    }

    const CacheManifest& m = *opt;

    // تحقق من الـ ABI
    if (m.abi != abi_) {
        LOGI("Manifest ABI mismatch: %s vs %s", m.abi.c_str(), abi_.c_str());
        return false;
    }

    // تحقق اختياري من المصدر
    if (!expected_source.empty() && m.source != expected_source) {
        LOGI("Manifest source mismatch");
        return false;
    }
    if (!expected_source_id.empty() && m.source_id != expected_source_id) {
        LOGI("Manifest source_id mismatch");
        return false;
    }

    // تحقق أن كل الملفات موجودة وحجمها صحيح
    if (!m.matchesDirectory(output_dir_)) {
        return false;
    }

    // تأكد أن libminecraftpe.so موجود وصالح
    std::string mainLib = output_dir_ + "/libminecraftpe.so";
    if (!LibraryFinder::isValidLibrary(mainLib)) {
        LOGI("libminecraftpe.so invalid despite manifest");
        return false;
    }

    LOGI("Cache is valid according to manifest (%zu files)", m.files.size());
    return true;
}

ExtractionResult LibraryExtractor::copyFromNativeDir(const std::string& native_lib_dir,
                                                     ProgressCallback cb) {
    ExtractionResult result;

    // -------- تحقق من الكاش أولاً --------
    if (isCacheValid("native", native_lib_dir)) {
        result.success = true;
        result.used_cache = true;
        result.extracted_path = output_dir_ + "/libminecraftpe.so";
        result.message = "Using existing valid cache";
        if (cb) cb(100, "Cache hit");
        LOGI("Cache hit – skipping copy");
        return result;
    }

    if (!ensureOutputDir()) {
        result.message = "Failed to create output directory";
        return result;
    }

    if (cb) cb(5, "Scanning native library directory");

    DIR* dir = opendir(native_lib_dir.c_str());
    if (!dir) {
        result.message = "Cannot open native library directory";
        return result;
    }

    std::vector<std::string> soFiles;
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;
        if (endsWith(name, ".so")) soFiles.push_back(name);
    }
    closedir(dir);

    if (soFiles.empty()) {
        result.message = "No .so files found in native library directory";
        return result;
    }

    int extracted = 0;
    const int total = static_cast<int>(soFiles.size());

    for (size_t i = 0; i < soFiles.size(); ++i) {
        const auto& name = soFiles[i];
        std::string src = native_lib_dir + "/" + name;
        std::string dst = output_dir_ + "/" + name;

        if (cb) {
            int percent = 10 + static_cast<int>((i * 80.0) / total);
            cb(percent, "Copying " + name);
        }

        if (copyFile(src, dst)) {
            result.extracted_files.push_back(name);
            extracted++;
        }
    }

    std::string main_lib = output_dir_ + "/libminecraftpe.so";
    if (LibraryFinder::isValidLibrary(main_lib)) {
        // كتابة الـ Manifest
        auto manifest = buildManifestFromDir("native", native_lib_dir);
        writeManifest(manifest);

        result.success = true;
        result.extracted_path = main_lib;
        result.message = "Successfully copied " + std::to_string(extracted) + " libraries";
        if (cb) cb(100, "Done");
    } else {
        result.message = "libminecraftpe.so was not found or is invalid after copy";
    }

    return result;
}

ExtractionResult LibraryExtractor::extractFromApk(const std::string& apk_path,
                                                  ProgressCallback cb) {
    ExtractionResult result;

    // -------- تحقق من الكاش أولاً --------
    // نستخدم حجم الملف + المسار كـ source_id بسيط
    std::string sourceId = apk_path + ":" + std::to_string(getFileSize(apk_path));

    if (isCacheValid("apk", sourceId)) {
        result.success = true;
        result.used_cache = true;
        result.extracted_path = output_dir_ + "/libminecraftpe.so";
        result.message = "Using existing valid cache";
        if (cb) cb(100, "Cache hit");
        LOGI("Cache hit – skipping APK extraction");
        return result;
    }

    if (!fileExists(apk_path)) {
        result.message = "APK file does not exist: " + apk_path;
        return result;
    }

    if (!ensureOutputDir()) {
        result.message = "Failed to create output directory";
        return result;
    }

    if (cb) cb(3, "Opening APK");

    unzFile zip = unzOpen(apk_path.c_str());
    if (!zip) {
        result.message = "Failed to open APK as zip";
        return result;
    }

    const std::string libPrefix = "lib/" + abi_ + "/";
    const size_t prefixLen = libPrefix.size();

    std::vector<std::string> soEntries;

    if (unzGoToFirstFile(zip) != UNZ_OK) {
        unzClose(zip);
        result.message = "APK appears empty or corrupted";
        return result;
    }

    do {
        char filename[512] = {};
        unz_file_info fileInfo;
        if (unzGetCurrentFileInfo(zip, &fileInfo, filename, sizeof(filename),
                                  nullptr, 0, nullptr, 0) != UNZ_OK) continue;

        std::string entry(filename);
        if (entry.size() > prefixLen &&
            entry.compare(0, prefixLen, libPrefix) == 0 &&
            endsWith(entry, ".so") &&
            entry.back() != '/') {
            soEntries.push_back(entry);
        }
    } while (unzGoToNextFile(zip) == UNZ_OK);

    if (soEntries.empty()) {
        unzClose(zip);
        result.message = "No .so files found in " + libPrefix;
        return result;
    }

    if (cb) cb(8, "Found " + std::to_string(soEntries.size()) + " libraries");

    int extractedCount = 0;
    const int total = static_cast<int>(soEntries.size());

    for (size_t i = 0; i < soEntries.size(); ++i) {
        const std::string& zipPath = soEntries[i];
        std::string name = zipPath.substr(prefixLen);
        std::string outPath = output_dir_ + "/" + name;

        if (cb) {
            int percent = 10 + static_cast<int>((i * 85.0) / total);
            cb(percent, "Extracting " + name);
        }

        if (unzLocateFile(zip, zipPath.c_str(), 0) != UNZ_OK) continue;

        if (extractOneFile(zip, outPath)) {
            result.extracted_files.push_back(name);
            extractedCount++;
        }
    }

    unzClose(zip);

    std::string main_lib = output_dir_ + "/libminecraftpe.so";
    if (LibraryFinder::isValidLibrary(main_lib)) {
        // كتابة الـ Manifest
        auto manifest = buildManifestFromDir("apk", sourceId);
        writeManifest(manifest);

        result.success = true;
        result.extracted_path = main_lib;
        result.message = "Successfully extracted " + std::to_string(extractedCount) + " libraries";
        if (cb) cb(100, "Extraction complete");
    } else {
        result.message = "libminecraftpe.so missing or invalid after extraction";
        if (cb) cb(100, "Failed");
    }

    return result;
}

ExtractionResult LibraryExtractor::rebuildCache(const std::string& source_path, bool is_apk,
                                                ProgressCallback cb) {
    if (is_apk) return extractFromApk(source_path, cb);
    return copyFromNativeDir(source_path, cb);
}

} // namespace levifix
