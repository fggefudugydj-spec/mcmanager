# LeviFix

مشروع تجريبي لحل مشكلة:

**`libminecraftpe.so not found in the Minecraft library cache`**

---

## حالة المشروع: جاهز للاستيراد في Android Studio

### ما يحتويه المشروع

| المكون | الوصف |
|--------|--------|
| **LibraryFinder** | بحث متعدد + التحقق من صحة ELF |
| **LibraryExtractor** | نسخ من nativeLibraryDir + استخراج كل `.so` من APK |
| **Cache Manifest** | ملف `.extraction_manifest` لمنع إعادة الاستخراج |
| **Progress Callback** | تحديث التقدم من C++ إلى Java |
| **RepairActivity** | واجهة تجريبية جاهزة |
| **minizip** | استخراج ملفات من APK |

---

## كيفية فتح المشروع

1. افتح **Android Studio**
2. اختر **Open** → حدد مجلد `LeviFix`
3. انتظر Gradle Sync
4. تأكد أن NDK مثبت (Android Studio → SDK Manager → SDK Tools → NDK)

---

## كيفية الاستخدام داخل كودك

```java
File cacheDir = new File(context.getFilesDir(), "minecraft_lib_cache");

String libPath = LibraryRepairHelper.tryRepair(
    context,
    cacheDir,
    null,  // أو مسار APK
    (percent, status) -> {
        // تحديث ProgressBar
    }
);

if (libPath != null) {
    // نجح الإصلاح
    System.load(libPath);
}
```

---

## ترتيب محاولات الإصلاح

1. البحث في الكاش الحالي
2. التحقق من ملف الـ Manifest
3. النسخ من `nativeLibraryDir` لماينكرافت الرسمية
4. الاستخراج من APK (إذا تم تمرير المسار)

---

## ملاحظات مهمة

- يحتاج **Android 9+** (minSdk 28)
- مخصص لـ **arm64-v8a**
- يجب أن تكون ماينكرافت الرسمية مثبتة وفتحتها مرة واحدة على الأقل
- المشروع تجريبي ويهدف للتعليم والتحسين

---

## الخطوات التالية المقترحة

- دمج الكود داخل LeviLauncher-Android
- إضافة دعم CRC32 حقيقي
- دعم أكثر من ABI
