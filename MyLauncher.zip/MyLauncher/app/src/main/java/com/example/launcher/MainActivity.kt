package com.example.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {

    private val versionsDir by lazy { File(filesDir, "versions").apply { mkdirs() } }
    private lateinit var list: ListView
    private lateinit var status: TextView
    private val REQ_IMPORT = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val importBtn = Button(this).apply { text = "Import Minecraft APK(s)" }
        status = TextView(this).apply { setPadding(0, 24, 0, 24); setTextIsSelectable(true) }
        list = ListView(this)
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
            addView(importBtn)
            addView(status)
            addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        })
        importBtn.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }, REQ_IMPORT)
        }
        list.setOnItemClickListener { _, _, pos, _ ->
            val name = list.adapter.getItem(pos) as String
            AlertDialog.Builder(this).setTitle(name)
                .setItems(arrayOf("Verify", "Launch", "Delete")) { _, i ->
                    when (i) {
                        0 -> verify(name)
                        1 -> status.text = "Launch is not implemented yet (stage 2). Verify first and send me the log."
                        2 -> { File(versionsDir, name).deleteRecursively(); refresh() }
                    }
                }.show()
        }
        refresh()
    }

    private fun refresh() {
        val names = versionsDir.listFiles()
            ?.filter { it.isDirectory && !it.name.startsWith("tmp_") }
            ?.map { it.name }?.sorted() ?: emptyList()
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
    }

    private fun apksOf(name: String): List<File> =
        File(versionsDir, name).listFiles { f -> f.extension == "apk" }?.sortedBy { it.name } ?: emptyList()

    private fun verify(name: String) {
        status.text = "Verifying $name ..."
        Thread {
            val apks = apksOf(name)
            val sb = StringBuilder("Version: $name\nAPKs: ${apks.size}\n")
            apks.forEach { sb.append(" - ${it.name} (${it.length() / 1024 / 1024} MB)\n") }
            when (val r = MinecraftLibraryCache.prepare(this, name, apks)) {
                is MinecraftLibraryCache.Result.Ok -> sb.append("\nOK (${r.abi})\n${r.mainLib.absolutePath}\n")
                is MinecraftLibraryCache.Result.Fail -> {
                    sb.append("\nFAILED: ${r.reason}\n")
                    r.details.forEach { sb.append(" * $it\n") }
                }
            }
            runOnUiThread { status.text = sb.toString() }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_IMPORT || resultCode != RESULT_OK || data == null) return
        val uris = buildList {
            data.clipData?.let { c -> for (i in 0 until c.itemCount) add(c.getItemAt(i).uri) }
            if (isEmpty()) data.data?.let { add(it) }
        }
        status.text = "Importing ${uris.size} file(s) ..."
        Thread {
            val tmp = File(versionsDir, "tmp_${System.currentTimeMillis()}").apply { mkdirs() }
            try {
                uris.forEachIndexed { i, uri ->
                    val dest = File(tmp, "part$i.apk")
                    contentResolver.openInputStream(uri)!!.use { inp -> dest.outputStream().use { inp.copyTo(it) } }
                }
                val infos = tmp.listFiles()!!.mapNotNull {
                    packageManager.getPackageArchiveInfo(it.path, 0)
                }
                val info = infos.firstOrNull()
                    ?: error("Not a valid APK file")
                if (info.packageName != MinecraftLibraryCache.MC_PACKAGE)
                    error("This is not the official Minecraft APK (package: ${info.packageName})")
                var label = (info.versionName ?: "unknown").replace(Regex("[^A-Za-z0-9._-]"), "_")
                var target = File(versionsDir, label)
                var n = 2
                while (target.exists()) { target = File(versionsDir, "${label}_$n"); n++ }
                tmp.renameTo(target)
                runOnUiThread { status.text = "Imported ${target.name}. Tap it, then Verify."; refresh() }
            } catch (e: Exception) {
                tmp.deleteRecursively()
                runOnUiThread { status.text = "Import failed: ${e.message}" }
            }
        }.start()
    }
}
