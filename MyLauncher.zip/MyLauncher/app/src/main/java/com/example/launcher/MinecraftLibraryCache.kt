package com.example.launcher

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.io.File
import java.util.zip.ZipFile

/**
 * Builds and validates the native library cache for a Minecraft version.
 * Fixes: "libminecraftpe.so not found in the Minecraft library cache"
 *
 * Handles: split APKs, ABI selection, atomic extraction, ELF validation,
 * and detailed diagnostics instead of a generic error.
 */
object MinecraftLibraryCache {

    const val MC_PACKAGE = "com.mojang.minecraftpe"
    const val MAIN_LIB = "libminecraftpe.so"
    private val EXTRA_LIBS = listOf("libc++_shared.so")

    sealed class Result {
        data class Ok(val libDir: File, val mainLib: File, val abi: String) : Result()
        data class Fail(val reason: String, val details: List<String>) : Result()
    }

    /** Prefer arm64-v8a; fall back to what the device supports. */
    private fun abiCandidates(): List<String> =
        Build.SUPPORTED_ABIS.toList().sortedBy { if (it == "arm64-v8a") 0 else 1 }

    /** APK paths of the installed official Minecraft (base + splits). */
    fun installedApkPaths(context: Context): List<File> = try {
        val info = context.packageManager.getApplicationInfo(MC_PACKAGE, 0)
        buildList {
            add(File(info.sourceDir))
            info.splitSourceDirs?.forEach { add(File(it)) }
        }
    } catch (e: PackageManager.NameNotFoundException) {
        emptyList()
    }

    /**
     * @param versionId unique id of the version/instance (used as cache folder)
     * @param apks base APK plus any split APKs (imported or installed)
     */
    fun prepare(context: Context, versionId: String, apks: List<File>): Result {
        val log = mutableListOf<String>()

        val existing = apks.filter { it.isFile && it.canRead() }
        apks.filterNot { it in existing }.forEach { log += "APK missing/unreadable: ${it.path}" }
        if (existing.isEmpty()) {
            return Result.Fail("No readable Minecraft APK. Import the official APK first.", log)
        }

        val abis = abiCandidates()
        log += "Device ABIs: ${abis.joinToString()}"

        for (abi in abis) {
            val outDir = File(context.codeCacheDir, "mc_libs/$versionId/$abi")
            val outMain = File(outDir, MAIN_LIB)

            // Reuse a valid cache.
            if (isValidElf(outMain)) return Result.Ok(outDir, outMain, abi)

            val entryName = "lib/$abi/$MAIN_LIB"
            val source = existing.firstOrNull { hasEntry(it, entryName) }
            if (source == null) {
                log += "No $entryName in any APK (${existing.size} checked)"
                continue
            }

            outDir.mkdirs()
            if (!outDir.isDirectory || !outDir.canWrite()) {
                return Result.Fail("Cache folder not writable: ${outDir.path}", log)
            }

            return try {
                extract(source, entryName, outMain)
                EXTRA_LIBS.forEach { lib ->
                    existing.firstOrNull { hasEntry(it, "lib/$abi/$lib") }
                        ?.let { extract(it, "lib/$abi/$lib", File(outDir, lib)) }
                }
                if (!isValidElf(outMain)) {
                    outMain.delete()
                    Result.Fail("Extracted $MAIN_LIB is corrupt. Re-import the APK.", log)
                } else {
                    Result.Ok(outDir, outMain, abi)
                }
            } catch (e: Exception) {
                Result.Fail("Extraction failed: ${e.message}", log + e.toString())
            }
        }

        // Last resort: installed app's own native dir (when libs are not compressed in APK).
        runCatching {
            val dir = context.packageManager.getApplicationInfo(MC_PACKAGE, 0).nativeLibraryDir
            val f = File(dir, MAIN_LIB)
            if (isValidElf(f)) return Result.Ok(File(dir), f, f.parentFile?.name ?: "native")
            log += "nativeLibraryDir has no valid $MAIN_LIB: $dir"
        }

        val hint = when {
            existing.size == 1 && log.any { it.startsWith("No lib/") } ->
                "The APK has no native libs. It is probably a split install: also import the config.arm64_v8a APK."
            else -> "Minecraft APK does not contain $MAIN_LIB for this device's ABI."
        }
        return Result.Fail(hint, log)
    }

    private fun hasEntry(apk: File, name: String): Boolean =
        runCatching { ZipFile(apk).use { it.getEntry(name) != null } }.getOrDefault(false)

    /** Atomic: write to .tmp then rename, so a crash never leaves a half file. */
    private fun extract(apk: File, entryName: String, dest: File) {
        val tmp = File(dest.parentFile, dest.name + ".tmp")
        ZipFile(apk).use { zip ->
            val entry = zip.getEntry(entryName) ?: error("Entry not found: $entryName")
            zip.getInputStream(entry).use { input ->
                tmp.outputStream().use { input.copyTo(it) }
            }
            if (tmp.length() != entry.size && entry.size >= 0) {
                tmp.delete()
                error("Size mismatch for $entryName")
            }
        }
        dest.delete()
        if (!tmp.renameTo(dest)) {
            tmp.copyTo(dest, overwrite = true)
            tmp.delete()
        }
        dest.setReadable(true, false)
        dest.setExecutable(true, false)
    }

    /** Checks the ELF magic number (0x7F 'E' 'L' 'F') and non-trivial size. */
    private fun isValidElf(f: File): Boolean = runCatching {
        f.isFile && f.length() > 1024 * 1024 && f.inputStream().use { s ->
            val h = ByteArray(4); s.read(h) == 4 &&
                h[0] == 0x7F.toByte() && h[1] == 'E'.code.toByte() &&
                h[2] == 'L'.code.toByte() && h[3] == 'F'.code.toByte()
        }
    }.getOrDefault(false)
}

/* Usage:
 *
 * val apks = MinecraftLibraryCache.installedApkPaths(context)   // or imported files
 * when (val r = MinecraftLibraryCache.prepare(context, "1.21.80", apks)) {
 *     is MinecraftLibraryCache.Result.Ok   -> System.load(r.mainLib.absolutePath)
 *     is MinecraftLibraryCache.Result.Fail -> showError(r.reason, r.details) // print details in Launch Log
 * }
 */
