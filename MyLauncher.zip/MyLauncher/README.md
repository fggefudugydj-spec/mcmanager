# MyLauncher (stage 1)
Version manager for official Minecraft Bedrock APKs: import (base + split APKs), validate, extract native libs with clear diagnostics.
Stage 2 (actual game launch) needs real device logs from stage 1.
Build: push to GitHub > Actions > Build APK > Artifacts.
